# Workspace

## Overview

pnpm workspace monorepo using TypeScript. "Tro Network" — a professional real-time AI chat web app with persistent memory, smart model routing, action tools, and structured citations.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React + Vite (artifacts/ai-chat), Clerk auth, dark theme
- **API framework**: Express 5 (artifacts/api-server)
- **Database**: PostgreSQL + Drizzle ORM
- **AI**: Smart model routing (gpt-5-mini standard/deep, gpt-5-nano trivial/titles), DALL-E images, Whisper/TTS voice
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Markdown**: react-markdown + remark-gfm + @tailwindcss/typography

## Key Features (What makes it different from standard AI apps)

- **Persistent Memory** — AI remembers facts about each user across all conversations forever (stored in `user_memories` table). Automatically extracts facts + explicit `save_memory` tool.
- **Speed-Optimized Routing** — gpt-5-mini for standard + deep messages, gpt-5-nano for trivial (instant). Keyword-based search detection (no LLM pre-call). Last-20-message window for long conversations (no summarization LLM call). Lean system prompt for minimal token overhead.
- **Message Edit/Delete** — Users can edit their sent messages (with Save or Save & Resend) and delete messages. Editing removes subsequent AI responses; deleting removes the message and everything after it.
- **Deep Reasoning** — System prompt enforces step-by-step thinking for logic, math, analysis, and complex questions. Breaks problems into parts, considers multiple angles, checks its own logic before answering.
- **Personal Partner AI** — Actively references stored memories in conversation, connects dots across sessions, tailors advice to the user's specific situation, anticipates needs, and matches the user's energy.
- **Action Tools** — AI can `create_task`, `complete_task`, `save_memory` — real actions, not just text output. Tasks viewable in sidebar Memory panel.
- **Proactive Behavior** — AI references pending tasks when relevant, proactively saves user preferences and interests, suggests next steps, and searches the web when uncertain rather than guessing.
- **Multi-Step Verification (Draft → Critique → Web-Verify → Refine)** — 4-layer accuracy pipeline: (1) AI generates response, (2) ruthless critic/hallucination detector finds errors, (3) web search verifies suspicious claims against real sources, (4) precision editor applies confirmed fixes. Runs silently post-stream, updates DB.
- **Pre-Response Intelligence** — Before the AI even starts generating, a fast classifier decides if the question needs real-time web data. If yes, results are pre-fetched and injected into context so the AI has facts BEFORE it starts writing — preventing hallucinations at the source.
- **Anti-Hallucination Protocol** — System prompt includes strict rules: never invent statistics, never fabricate sources, hedge when uncertain, search when not 95%+ confident. Combined with pre-search + post-verification, this is a triple-layer defense.
- **Smart Context Window** — Long chats automatically keep only the last 20 messages in context (no expensive summarization LLM call). Memories provide persistent cross-conversation context.
- **Thinking Pipeline UI** — Users see "Researching…", "Analyzing conversation context…", "Thinking…" status indicators showing the multi-stage reasoning process.
- **Evolving Memory System** — Not just storing facts. The memory system detects patterns in user behavior ("Tends to ask about X frequently"), generates insights ("Seems to be preparing for a career change"), and intelligently updates outdated memories instead of creating duplicates. Builds a real evolving user profile over time.
- **Structured Citations** — Web search results always include [Source Name](URL) citations. System prompt enforces attribution.
- **Web search** with live status indicators
- **URL reading** — paste any link, AI reads and analyzes it
- **Image generation** (DALL-E) — runs in parallel with text streaming
- **Camera capture** with AI annotation overlays
- **Voice mode** with STT + AI + TTS
- **Per-user PostgreSQL** conversation history (Clerk auth)
- **AI-generated titles** (gpt-5-nano)
- **PWA installability**
- **Full markdown rendering** (headers, tables, code blocks, lists, links, blockquotes)

## DB Schema

- `conversations` — id, userId, title, createdAt, updatedAt
- `messages` — id, conversationId, role, content, imageData, annotationData, createdAt
- `user_memories` — id, userId, content, category (preference/fact/context/goal), createdAt, updatedAt
- `user_tasks` — id, userId, title, description, dueDate, completed, createdAt, updatedAt

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

## Architecture Notes

- **Clerk auth**: Keys auto-provisioned, proxy path `/__clerk`, do NOT use `<UserButton />`
- **Vite Clerk key**: Injected via `define` in vite.config.ts
- **AI tools**: `web_search`, `fetch_url`, `generate_image`, `save_memory`, `create_task`, `complete_task` — multi-round loop (max 6)
- **Memory**: Dual approach — explicit tool calls + background auto-extraction after each response via gpt-5-nano
- **Self-correction**: `verifySelfCorrect()` runs after `res.end()` with 4 steps: (1) critique+hallucination detection, (2) web verification of suspicious claims, (3) precision editing. Updates DB silently. Frontend picks up corrections via query invalidation.
- **Pre-response intelligence**: `shouldForceSearch()` runs in parallel with memory/task loading. If the question needs current facts, web results are pre-fetched and injected into the system prompt BEFORE streaming starts.
- **Context window**: Keeps last 20 messages for long conversations, no LLM summarization. Memories carry cross-conversation context.
- **Model routing**: `selectModel()` analyzes message length + keywords to pick optimal model
- **Streaming**: SSE events: `status` (tool progress), `content` (text chunks), `image`, `annotation`, `replaceContent`, `done`
- **API endpoints**: `/api/openai/memories` (GET, DELETE), `/api/openai/tasks` (GET, PATCH, DELETE)

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
