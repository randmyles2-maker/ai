import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { Menu, ArrowRight, Loader2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { ChatSidebar } from "@/components/chat-sidebar";
import { ChatArea } from "@/components/chat-area";
import {
  useCreateOpenaiConversation,
  getListOpenaiConversationsQueryKey,
} from "@workspace/api-client-react";

export function ChatPage() {
  const params = useParams<{ id?: string }>();
  const activeId = params.id;
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="flex h-[100dvh] w-full bg-background overflow-hidden selection:bg-primary/20 selection:text-foreground">
      <div className="hidden md:flex w-[280px] shrink-0 flex-col relative z-20">
        <ChatSidebar activeId={activeId} />
      </div>

      <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
        <SheetContent side="left" className="p-0 w-[280px] border-r-0">
          <ChatSidebar activeId={activeId} onMobileClose={() => setMobileMenuOpen(false)} />
        </SheetContent>
      </Sheet>

      <main className="flex-1 flex flex-col min-w-0 min-h-0">
        <div className="md:hidden flex items-center px-4 border-b bg-background/95 backdrop-blur z-20 shrink-0"
          style={{ paddingTop: `calc(env(safe-area-inset-top) + 8px)`, paddingBottom: "8px", minHeight: "48px" }}>
          <Button variant="ghost" size="icon" className="-ml-2 mr-2 text-foreground/70 h-10 w-10" onClick={() => setMobileMenuOpen(true)}>
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded overflow-hidden">
              <img src="/icon.png" alt="Tro" className="h-full w-full object-cover" />
            </div>
            <span className="font-semibold text-sm">Tro Network</span>
          </div>
        </div>

        {activeId ? (
          <ChatArea conversationId={activeId} hideTitleBar={false} />
        ) : (
          <EmptyState />
        )}
      </main>
    </div>
  );
}

function EmptyState() {
  const [_, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const createConversation = useCreateOpenaiConversation();

  const suggestions = [
    "What's new in AI today?",
    "Explain a concept to me",
    "Help me write something",
    "Solve a problem together",
  ];

  const handleSuggestionClick = (text: string) => {
    createConversation.mutate(
      { data: { title: text.slice(0, 30) } },
      {
        onSuccess: (newConv) => {
          queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
          setLocation(`/chat/${newConv.id}`);
        },
      }
    );
  };

  return (
    <div className="flex flex-1 min-h-0 w-full flex-col items-center justify-center p-6 bg-background">
      <div className="max-w-2xl w-full flex flex-col items-center text-center space-y-10 animate-fade-in">
        <div className="space-y-4">
          <div className="mx-auto h-16 w-16 rounded-2xl overflow-hidden border border-border/40 shadow-sm">
            <img src="/icon.png" alt="Tro Network" className="h-full w-full object-cover" />
          </div>
          <h2 className="text-3xl font-semibold tracking-tight text-foreground">
            Welcome to Tro Network
          </h2>
          <p className="text-muted-foreground text-lg max-w-lg mx-auto">
            Your intelligent assistant, always up to date. Ask anything — I'm here to help.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-lg mx-auto">
          {suggestions.map((text, i) => (
            <button
              key={i}
              disabled={createConversation.isPending}
              onClick={() => handleSuggestionClick(text)}
              className="flex items-center justify-between p-4 rounded-xl border bg-card text-left hover:bg-accent hover:border-accent-foreground/20 transition-all group disabled:opacity-50"
            >
              <span className="text-sm font-medium text-foreground/80 group-hover:text-foreground">{text}</span>
              <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors transform group-hover:translate-x-0.5" />
            </button>
          ))}
        </div>

        {createConversation.isPending && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            Starting conversation...
          </div>
        )}
      </div>
    </div>
  );
}
