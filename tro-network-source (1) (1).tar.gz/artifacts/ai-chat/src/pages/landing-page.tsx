import { useLocation } from "wouter";
import {
  Brain,
  Shield,
  Sparkles,
  Globe,
  Mic,
  Camera,
  Search,
  Bell,
  Download,
  X,
  ArrowRight,
  Eye,
} from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { usePwaInstall } from "@/hooks/use-pwa-install";

function FloatingOrbs() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      <div className="orb orb-1" />
      <div className="orb orb-2" />
      <div className="orb orb-3" />
    </div>
  );
}

function TypewriterText({ text, delay = 0 }: { text: string; delay?: number }) {
  const [displayed, setDisplayed] = useState("");
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setStarted(true), delay);
    return () => clearTimeout(t);
  }, [delay]);

  useEffect(() => {
    if (!started) return;
    let i = 0;
    const interval = setInterval(() => {
      i++;
      setDisplayed(text.slice(0, i));
      if (i >= text.length) clearInterval(interval);
    }, 40);
    return () => clearInterval(interval);
  }, [started, text]);

  return (
    <span>
      {displayed}
      {started && displayed.length < text.length && (
        <span className="inline-block w-[2px] h-[1em] bg-primary ml-0.5 animate-cursor-blink align-text-bottom" />
      )}
    </span>
  );
}

function AnimatedCounter({ target, suffix = "", delay = 0 }: { target: number; suffix?: string; delay?: number }) {
  const [count, setCount] = useState(0);
  const [started, setStarted] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry?.isIntersecting) setStarted(true); },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!started) return;
    const timer = setTimeout(() => {
      const duration = 1200;
      const steps = 30;
      const increment = target / steps;
      let current = 0;
      const interval = setInterval(() => {
        current += increment;
        if (current >= target) {
          setCount(target);
          clearInterval(interval);
        } else {
          setCount(Math.floor(current));
        }
      }, duration / steps);
      return () => clearInterval(interval);
    }, delay);
    return () => clearTimeout(timer);
  }, [started, target, delay]);

  return <span ref={ref}>{count}{suffix}</span>;
}

const FEATURES = [
  {
    icon: Brain,
    title: "Remembers everything",
    desc: "Persistent memory that evolves across every conversation. It knows your name, your goals, your preferences.",
    gradient: "from-violet-500/20 to-purple-500/20",
    iconColor: "text-violet-400",
  },
  {
    icon: Eye,
    title: "Self-correcting",
    desc: "Every answer goes through a multi-step verification pipeline. It critiques itself, checks suspicious claims, then fixes errors automatically.",
    gradient: "from-cyan-500/20 to-blue-500/20",
    iconColor: "text-cyan-400",
  },
  {
    icon: Search,
    title: "Always current",
    desc: "Automatically searches the web for questions that need real-time data. No outdated answers, no guessing.",
    gradient: "from-emerald-500/20 to-green-500/20",
    iconColor: "text-emerald-400",
  },
  {
    icon: Sparkles,
    title: "Creates images",
    desc: "Describe what you want and it generates it in seconds — while still streaming text. Parallel processing.",
    gradient: "from-amber-500/20 to-yellow-500/20",
    iconColor: "text-amber-400",
  },
  {
    icon: Mic,
    title: "Voice mode",
    desc: "Speak naturally, hear it respond. Full speech-to-text and text-to-speech built in. Hands-free.",
    gradient: "from-rose-500/20 to-pink-500/20",
    iconColor: "text-rose-400",
  },
  {
    icon: Camera,
    title: "Sees and annotates",
    desc: "Take a photo or upload an image. It analyzes what it sees and highlights relevant regions with annotations.",
    gradient: "from-indigo-500/20 to-blue-500/20",
    iconColor: "text-indigo-400",
  },
  {
    icon: Globe,
    title: "Every language",
    desc: "Write in any human language — it detects and responds in kind with proper grammar and script.",
    gradient: "from-teal-500/20 to-cyan-500/20",
    iconColor: "text-teal-400",
  },
  {
    icon: Bell,
    title: "Tasks & reminders",
    desc: "Tell it to remember something or remind you later. Tracks deadlines and proactively surfaces pending items.",
    gradient: "from-orange-500/20 to-red-500/20",
    iconColor: "text-orange-400",
  },
];

const STATS = [
  { value: 4, suffix: "-step", label: "Verification pipeline" },
  { value: 30, suffix: "+", label: "Built-in capabilities" },
  { value: 100, suffix: "+", label: "Languages supported" },
  { value: 0, suffix: "", label: "Data shared with others", display: "Zero" },
];

export function LandingPage() {
  const [, setLocation] = useLocation();
  const { canInstall, install } = usePwaInstall();
  const [bannerDismissed, setBannerDismissed] = useState(false);

  const showBanner = canInstall && !bannerDismissed;

  return (
    <>
      <div className="flex min-h-screen flex-col bg-background text-foreground overflow-x-hidden">
        <FloatingOrbs />

        <header
          className="sticky top-0 z-50 flex items-center justify-between px-6 py-3 bg-background/80 backdrop-blur-xl border-b border-border/30"
          style={{ paddingTop: `calc(env(safe-area-inset-top) + 0.75rem)` }}
        >
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-lg overflow-hidden ring-1 ring-border/40">
              <img src="/icon.png" alt="Tro" className="h-full w-full object-cover" />
            </div>
            <span className="font-semibold tracking-tight text-[15px]">Tro Network</span>
          </div>
          <div className="flex items-center gap-2">
            {canInstall && (
              <Button variant="outline" size="sm" className="gap-1.5 hidden sm:flex text-xs" onClick={install}>
                <Download className="h-3.5 w-3.5" />
                Install
              </Button>
            )}
            <Button variant="ghost" size="sm" className="text-xs" onClick={() => setLocation("/sign-in")}>
              Sign in
            </Button>
            <Button size="sm" className="text-xs gap-1" onClick={() => setLocation("/sign-up")}>
              Get started
              <ArrowRight className="h-3 w-3" />
            </Button>
          </div>
        </header>

        {showBanner && (
          <div className="flex items-center gap-3 px-4 py-3 bg-primary/10 border-b border-primary/20 sm:hidden">
            <div className="h-9 w-9 rounded-xl overflow-hidden shrink-0">
              <img src="/icon.png" alt="Tro" className="h-full w-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground">Add Tro to your home screen</p>
              <p className="text-xs text-muted-foreground">Quick access anytime</p>
            </div>
            <Button size="sm" className="shrink-0 gap-1.5 h-8 px-3 text-xs" onClick={install}>
              <Download className="h-3 w-3" />
              Install
            </Button>
            <button
              onClick={() => setBannerDismissed(true)}
              className="h-7 w-7 shrink-0 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors"
              aria-label="Dismiss install banner"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        <section className="relative flex flex-col items-center justify-center px-6 pt-20 pb-16 sm:pt-28 sm:pb-24 text-center">
          <div className="mx-auto max-w-3xl space-y-8">
            <div className="mx-auto h-20 w-20 rounded-2xl overflow-hidden ring-2 ring-primary/20 shadow-lg shadow-primary/10">
              <img src="/icon.png" alt="Tro Network" className="h-full w-full object-cover" />
            </div>

            <h1 className="text-4xl sm:text-6xl font-bold tracking-tight leading-[1.1]">
              <span className="bg-gradient-to-r from-foreground via-foreground to-muted-foreground bg-clip-text">
                The AI that
              </span>
              <br />
              <span className="bg-gradient-to-r from-primary via-cyan-400 to-primary bg-clip-text text-transparent">
                <TypewriterText text="actually knows you" delay={400} />
              </span>
            </h1>

            <p className="text-lg sm:text-xl text-muted-foreground max-w-xl mx-auto leading-relaxed">
              Persistent memory. Self-correcting answers. Real-time intelligence.
              <span className="hidden sm:inline"> A private AI that evolves with every conversation.</span>
            </p>

            <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
              <Button
                size="lg"
                className="gap-2 text-base px-8 h-12 rounded-xl shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all"
                onClick={() => setLocation("/sign-up")}
              >
                Start for free
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="gap-2 text-base px-8 h-12 rounded-xl"
                onClick={() => setLocation("/sign-in")}
              >
                Sign in
              </Button>
            </div>

            <p className="text-xs text-muted-foreground/60 pt-2">
              Free to use · No credit card · Your data stays private
            </p>
          </div>

          <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-background to-transparent" />
        </section>

        <section className="relative border-y border-border/30 bg-card/50 backdrop-blur-sm">
          <div className="max-w-5xl mx-auto grid grid-cols-2 sm:grid-cols-4 divide-x divide-border/30">
            {STATS.map((stat, i) => (
              <div key={stat.label} className="px-6 py-8 text-center">
                <div className="text-2xl sm:text-3xl font-bold text-foreground">
                  {stat.display || <AnimatedCounter target={stat.value} suffix={stat.suffix} delay={i * 150} />}
                </div>
                <div className="text-xs sm:text-sm text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </section>

        <section className="px-6 py-20 sm:py-28">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-16 space-y-4">
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">
                Not just another chatbot
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto text-base sm:text-lg">
                Most AIs forget you the moment you close the tab. Tro Network remembers, verifies, and improves — every single time.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-20">
              {[
                { step: "01", title: "Understand", desc: "Loads your memory profile and analyzes intent", color: "bg-violet-500" },
                { step: "02", title: "Research", desc: "Pre-fetches web data if facts are needed", color: "bg-cyan-500" },
                { step: "03", title: "Generate", desc: "Streams the response in real-time", color: "bg-emerald-500" },
                { step: "04", title: "Verify", desc: "Self-critiques, checks claims, and auto-corrects", color: "bg-amber-500" },
              ].map((step, i) => (
                <div key={step.step} className="landing-step relative flex flex-col items-center text-center p-6 rounded-2xl border border-border/40 bg-card/60 backdrop-blur-sm" style={{ animationDelay: `${i * 150}ms` }}>
                  <div className={`h-10 w-10 rounded-xl ${step.color} flex items-center justify-center text-white text-sm font-bold mb-3`}>
                    {step.step}
                  </div>
                  <h3 className="font-semibold text-sm mb-1">{step.title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{step.desc}</p>
                  {i < 3 && (
                    <div className="hidden sm:block absolute -right-3 top-1/2 -translate-y-1/2 text-muted-foreground/30">
                      <ArrowRight className="h-5 w-5" />
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {FEATURES.map((feat, i) => (
                <div
                  key={feat.title}
                  className="landing-card group relative rounded-2xl border border-border/40 bg-card/60 backdrop-blur-sm p-5 space-y-3 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300 cursor-default"
                  style={{ animationDelay: `${i * 80}ms` }}
                >
                  <div className={`h-10 w-10 rounded-xl bg-gradient-to-br ${feat.gradient} flex items-center justify-center ${feat.iconColor} group-hover:scale-110 transition-transform duration-300`}>
                    <feat.icon className="h-5 w-5" />
                  </div>
                  <h3 className="font-semibold text-sm">{feat.title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{feat.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="px-6 py-20 border-t border-border/30">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <div className="mx-auto h-14 w-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
              <Shield className="h-7 w-7 text-primary" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
              Your conversations are yours alone
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Every message, memory, and task is tied to your account. No one else can access it. No training on your data. No sharing. Period.
            </p>
            <div className="flex flex-wrap gap-3 justify-center pt-2">
              {["End-to-end private", "Per-user isolation", "No data training", "Delete anytime"].map((item) => (
                <span
                  key={item}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/5 border border-primary/10 text-xs font-medium text-primary"
                >
                  <Shield className="h-3 w-3" />
                  {item}
                </span>
              ))}
            </div>
          </div>
        </section>

        <section className="px-6 py-20 sm:py-28 border-t border-border/30">
          <div className="max-w-2xl mx-auto text-center space-y-8">
            <div className="space-y-4">
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">
                Ready to meet your AI?
              </h2>
              <p className="text-muted-foreground text-lg">
                Free, private, and smarter than anything you've tried.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button
                size="lg"
                className="gap-2 text-base px-10 h-12 rounded-xl shadow-lg shadow-primary/20"
                onClick={() => setLocation("/sign-up")}
              >
                Get started free
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
            {canInstall && (
              <button
                onClick={install}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-border/60 bg-card hover:bg-accent transition-colors text-sm text-muted-foreground hover:text-foreground"
              >
                <Download className="h-4 w-4" />
                Install as app
              </button>
            )}
          </div>
        </section>

        <footer className="px-6 py-6 border-t border-border/30 text-center">
          <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground/50">
            <div className="h-4 w-4 rounded overflow-hidden opacity-50">
              <img src="/icon.png" alt="" className="h-full w-full object-cover" />
            </div>
            Tro Network · {new Date().getFullYear()}
          </div>
        </footer>
      </div>
    </>
  );
}
