import React from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

export function Markdown({ content }: { content: string }) {
  return (
    <div className="prose prose-invert prose-sm max-w-none font-sans leading-relaxed text-[15px]
      prose-headings:font-semibold prose-headings:tracking-tight prose-headings:text-foreground
      prose-h1:text-xl prose-h1:mt-6 prose-h1:mb-3
      prose-h2:text-lg prose-h2:mt-5 prose-h2:mb-2
      prose-h3:text-base prose-h3:mt-4 prose-h3:mb-2
      prose-p:my-2 prose-p:text-foreground/90 prose-p:leading-relaxed
      prose-strong:font-semibold prose-strong:text-foreground
      prose-em:text-foreground/80
      prose-a:text-primary prose-a:underline prose-a:underline-offset-2 hover:prose-a:text-primary/80
      prose-ul:my-2 prose-ul:pl-4 prose-ol:my-2 prose-ol:pl-4
      prose-li:my-0.5 prose-li:text-foreground/90
      prose-blockquote:border-l-2 prose-blockquote:border-primary/40 prose-blockquote:pl-4 prose-blockquote:italic prose-blockquote:text-foreground/70
      prose-hr:border-border/50 prose-hr:my-4
      prose-table:text-sm
      prose-th:text-left prose-th:py-2 prose-th:px-3 prose-th:border-b prose-th:border-border/60 prose-th:text-foreground prose-th:font-semibold prose-th:bg-secondary/30
      prose-td:py-2 prose-td:px-3 prose-td:border-b prose-td:border-border/30 prose-td:text-foreground/90
      prose-img:rounded-lg prose-img:border prose-img:border-border/40
    ">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          pre({ children }) {
            return <>{children}</>;
          },
          code({ className, children, ...props }) {
            const match = /language-(\w+)/.exec(className || "");
            const code = String(children).replace(/\n$/, "");
            if (match || code.includes("\n")) {
              return (
                <div className="my-4 rounded-md overflow-hidden border border-border/50 bg-secondary/30 not-prose">
                  {match && (
                    <div className="px-4 py-1.5 text-xs font-mono text-muted-foreground bg-secondary/50 border-b border-border/50">
                      {match[1]}
                    </div>
                  )}
                  <pre className="p-4 overflow-x-auto text-sm font-mono text-secondary-foreground">
                    <code>{code}</code>
                  </pre>
                </div>
              );
            }
            return (
              <code className="px-1.5 py-0.5 rounded bg-secondary text-secondary-foreground font-mono text-[13px]" {...props}>
                {children}
              </code>
            );
          },
          table({ children }) {
            return (
              <div className="my-4 overflow-x-auto rounded-md border border-border/50">
                <table className="w-full text-sm">{children}</table>
              </div>
            );
          },
          a({ href, children }) {
            return (
              <a href={href} target="_blank" rel="noopener noreferrer" className="text-primary underline underline-offset-2 hover:text-primary/80">
                {children}
              </a>
            );
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
