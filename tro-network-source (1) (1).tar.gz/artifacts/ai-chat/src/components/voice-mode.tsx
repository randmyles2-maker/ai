import { useEffect, useRef, useState, useCallback } from "react";
import { X, Mic, MicOff } from "lucide-react";

type VoiceState = "idle" | "listening" | "processing" | "speaking";

interface VoiceModeProps {
  conversationId: number;
  onClose: () => void;
  onMessagesUpdated: () => void;
}

function bufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunkSize = 8192;
  for (let i = 0; i < bytes.byteLength; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function base64ToBlob(base64: string, mimeType: string): Blob {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mimeType });
}

export function VoiceMode({ conversationId, onClose, onMessagesUpdated }: VoiceModeProps) {
  const [state, setState] = useState<VoiceState>("idle");
  const [transcript, setTranscript] = useState("");
  const [aiText, setAiText] = useState("");
  const [error, setError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const mountedRef = useRef(true);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      // Cancel any in-flight fetch
      abortRef.current?.abort();
      // Stop recording
      if (mediaRecorderRef.current?.state === "recording") {
        mediaRecorderRef.current.stop();
      }
      streamRef.current?.getTracks().forEach((t) => t.stop());
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      audioCtxRef.current?.close().catch(() => {});
      audioRef.current?.pause();
    };
  }, []);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const safeSet = useCallback((setter: React.Dispatch<React.SetStateAction<any>>, value: any) => {
    if (mountedRef.current) setter(value);
  }, []);

  const startListening = async () => {
    safeSet(setError, null);
    safeSet(setTranscript, "");
    safeSet(setAiText, "");

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (!mountedRef.current) { stream.getTracks().forEach((t) => t.stop()); return; }
      streamRef.current = stream;

      const audioCtx = new AudioContext();
      audioCtxRef.current = audioCtx;
      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      const dataArray = new Uint8Array(analyser.frequencyBinCount);

      const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
        ? "audio/webm;codecs=opus"
        : MediaRecorder.isTypeSupported("audio/webm")
        ? "audio/webm"
        : "audio/mp4";

      const recorder = new MediaRecorder(stream, { mimeType });
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };

      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        audioCtx.close().catch(() => {});
        if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);

        if (!mountedRef.current || chunksRef.current.length === 0) {
          safeSet(setState, "idle");
          return;
        }

        safeSet(setState, "processing");
        const blob = new Blob(chunksRef.current, { type: mimeType });

        try {
          const arrayBuf = await blob.arrayBuffer();
          const base64 = bufferToBase64(arrayBuf);

          const controller = new AbortController();
          abortRef.current = controller;

          const res = await fetch(`/api/openai/conversations/${conversationId}/voice`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ audioBase64: base64, mimeType }),
            signal: controller.signal,
          });

          if (!mountedRef.current) return;
          if (!res.ok) throw new Error(`Server error ${res.status}`);

          const data = await res.json() as { transcript: string; aiText: string; audioBase64: string };
          if (!mountedRef.current) return;

          if (!data.transcript?.trim()) {
            safeSet(setState, "idle");
            return;
          }

          safeSet(setTranscript, data.transcript);
          safeSet(setAiText, data.aiText);
          onMessagesUpdated();

          if (data.audioBase64 && mountedRef.current) {
            safeSet(setState, "speaking");
            const audioBlob = base64ToBlob(data.audioBase64, "audio/mp3");
            const audioUrl = URL.createObjectURL(audioBlob);
            const audio = new Audio(audioUrl);
            audioRef.current = audio;
            audio.onended = () => {
              URL.revokeObjectURL(audioUrl);
              safeSet(setState, "idle");
            };
            audio.onerror = () => {
              URL.revokeObjectURL(audioUrl);
              safeSet(setState, "idle");
            };
            try { await audio.play(); } catch { safeSet(setState, "idle"); }
          } else {
            safeSet(setState, "idle");
          }
        } catch (err: any) {
          if (err?.name === "AbortError") return;
          console.error("Voice error:", err);
          safeSet(setError, "Something went wrong. Please try again.");
          safeSet(setState, "idle");
        }
      };

      recorder.start();
      safeSet(setState, "listening");

      // Silence detection — stops after 2s of silence, minimum 1.5s recording
      let silenceStart: number | null = null;
      const startedAt = Date.now();

      const checkSilence = () => {
        if (!mountedRef.current || recorder.state !== "recording") return;
        analyser.getByteFrequencyData(dataArray);
        const avg = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
        const elapsed = Date.now() - startedAt;

        if (elapsed > 1500) {
          if (avg < 6) {
            if (!silenceStart) silenceStart = Date.now();
            else if (Date.now() - silenceStart > 2000) {
              recorder.stop();
              return;
            }
          } else {
            silenceStart = null;
          }
        }
        animFrameRef.current = requestAnimationFrame(checkSilence);
      };
      animFrameRef.current = requestAnimationFrame(checkSilence);

    } catch (err: any) {
      safeSet(setError, "Microphone access denied.");
      safeSet(setState, "idle");
    }
  };

  const stopListening = () => {
    if (mediaRecorderRef.current?.state === "recording") mediaRecorderRef.current.stop();
  };

  const stopSpeaking = () => {
    audioRef.current?.pause();
    safeSet(setState, "idle");
  };

  const handleMicAction = () => {
    if (state === "idle") startListening();
    else if (state === "listening") stopListening();
    else if (state === "speaking") stopSpeaking();
  };

  const stateColor = {
    idle: "#06b6d4",
    listening: "#22c55e",
    processing: "#f59e0b",
    speaking: "#a855f7",
  }[state];

  const micBg = {
    idle: "#06b6d4",
    listening: "#ef4444",
    processing: "#f59e0b",
    speaking: "#a855f7",
  }[state];

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col items-center justify-between select-none"
      style={{
        background: "linear-gradient(160deg, #060d1a 0%, #0a0f1e 60%, #0c0a1a 100%)",
        paddingTop: "env(safe-area-inset-top)",
        paddingBottom: "env(safe-area-inset-bottom)",
      }}
    >
      {/* Top bar */}
      <div className="w-full flex items-center justify-between px-6 pt-5">
        <span className="text-white/40 text-xs font-semibold tracking-[0.2em] uppercase">Voice Mode</span>
        <button
          onClick={onClose}
          className="h-9 w-9 rounded-full bg-white/10 flex items-center justify-center text-white/50 hover:text-white hover:bg-white/15 transition-colors"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Orb + status + text */}
      <div className="flex flex-col items-center gap-10 flex-1 justify-center w-full">
        {/* Animated orb */}
        <div className="relative flex items-center justify-center" style={{ width: 220, height: 220 }}>
          {(state === "listening" || state === "speaking") && (
            <>
              <div className="absolute inset-0 rounded-full animate-ping"
                style={{ background: `${stateColor}0a`, animationDuration: "2s" }} />
              <div className="absolute rounded-full animate-ping"
                style={{ inset: 20, background: `${stateColor}12`, animationDuration: "2s", animationDelay: "0.4s" }} />
              <div className="absolute rounded-full animate-ping"
                style={{ inset: 40, background: `${stateColor}18`, animationDuration: "2s", animationDelay: "0.8s" }} />
            </>
          )}
          {state === "processing" && (
            <div className="absolute rounded-full animate-spin"
              style={{ inset: 30, border: `2px solid ${stateColor}25`, borderTopColor: stateColor, animationDuration: "1s" }} />
          )}
          <div
            className="relative rounded-full flex items-center justify-center"
            style={{
              width: state === "listening" ? 110 : 90,
              height: state === "listening" ? 110 : 90,
              background: `radial-gradient(circle at 35% 30%, ${stateColor}dd, ${stateColor}55)`,
              boxShadow: `0 0 50px ${stateColor}55, 0 0 100px ${stateColor}22, inset 0 1px 0 ${stateColor}88`,
              transition: "width 0.3s ease, height 0.3s ease, background 0.4s ease, box-shadow 0.4s ease",
            }}
          >
            {state === "idle" && <Mic className="h-7 w-7 text-white drop-shadow" />}
            {state === "listening" && <Mic className="h-9 w-9 text-white drop-shadow" />}
            {state === "processing" && <div className="h-6 w-6 rounded-full border-2 border-white border-t-transparent animate-spin" />}
            {state === "speaking" && (
              <div className="flex gap-[3px] items-end" style={{ height: 28 }}>
                {[40, 70, 55, 90, 60, 75, 45].map((h, i) => (
                  <div key={i} className="w-[3px] rounded-full bg-white animate-bounce"
                    style={{ height: `${h}%`, animationDelay: `${i * 0.07}s`, animationDuration: "0.6s" }} />
                ))}
              </div>
            )}
          </div>
        </div>

        <p
          className="text-sm tracking-widest uppercase font-medium transition-colors duration-300"
          style={{ color: state === "idle" ? "rgba(255,255,255,0.35)" : stateColor }}
        >
          {state === "idle" && "Tap to speak"}
          {state === "listening" && "Listening…"}
          {state === "processing" && "Thinking…"}
          {state === "speaking" && "Speaking…"}
        </p>

        <div className="w-full max-w-xs px-8 flex flex-col gap-5 text-center" style={{ minHeight: 130 }}>
          {transcript ? (
            <div className="animate-fade-in">
              <p className="text-white/25 text-[10px] mb-1.5 uppercase tracking-[0.2em]">You</p>
              <p className="text-white/80 text-[15px] leading-relaxed">{transcript}</p>
            </div>
          ) : null}
          {aiText ? (
            <div className="animate-fade-in">
              <p className="text-white/25 text-[10px] mb-1.5 uppercase tracking-[0.2em]">Tro Network</p>
              <p className="text-[15px] leading-relaxed" style={{ color: stateColor }}>{aiText}</p>
            </div>
          ) : null}
        </div>

        {error && <p className="text-red-400/70 text-sm px-8 text-center animate-fade-in">{error}</p>}
      </div>

      {/* Mic button */}
      <div className="pb-14 flex flex-col items-center gap-3">
        <button
          onClick={handleMicAction}
          disabled={state === "processing"}
          className="h-[72px] w-[72px] rounded-full flex items-center justify-center transition-all duration-200 disabled:opacity-40 active:scale-90"
          style={{ background: micBg, boxShadow: `0 0 32px ${micBg}88, 0 4px 24px rgba(0,0,0,0.4)` }}
        >
          {state === "listening"
            ? <MicOff className="h-7 w-7 text-white drop-shadow" />
            : <Mic className="h-7 w-7 text-white drop-shadow" />
          }
        </button>
        {state === "listening" && <p className="text-white/30 text-[11px]">Tap to stop</p>}
        {state === "speaking" && <p className="text-white/30 text-[11px]">Tap to interrupt</p>}
      </div>
    </div>
  );
}
