import { useState, useEffect } from "react";
import { Brain, CheckSquare, Square, Trash2, X, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Memory {
  id: number;
  content: string;
  category: string;
  createdAt: string;
}

interface Task {
  id: number;
  title: string;
  description: string | null;
  dueDate: string | null;
  completed: boolean;
  createdAt: string;
}

export function MemoryPanel({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<"memory" | "tasks">("memory");
  const [memories, setMemories] = useState<Memory[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [memRes, taskRes] = await Promise.all([
        fetch("/api/openai/memories"),
        fetch("/api/openai/tasks"),
      ]);
      if (memRes.ok) setMemories(await memRes.json());
      if (taskRes.ok) setTasks(await taskRes.json());
    } catch {}
    setLoading(false);
  };

  const deleteMemory = async (id: number) => {
    await fetch(`/api/openai/memories/${id}`, { method: "DELETE" });
    setMemories((prev) => prev.filter((m) => m.id !== id));
  };

  const toggleTask = async (id: number, completed: boolean) => {
    const res = await fetch(`/api/openai/tasks/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ completed: !completed }),
    });
    if (res.ok) {
      setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, completed: !completed } : t)));
    }
  };

  const deleteTask = async (id: number) => {
    await fetch(`/api/openai/tasks/${id}`, { method: "DELETE" });
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const categoryColors: Record<string, string> = {
    preference: "bg-purple-500/20 text-purple-400",
    fact: "bg-blue-500/20 text-blue-400",
    context: "bg-amber-500/20 text-amber-400",
    goal: "bg-green-500/20 text-green-400",
  };

  const pendingTasks = tasks.filter((t) => !t.completed);
  const completedTasks = tasks.filter((t) => t.completed);
  const [showCompleted, setShowCompleted] = useState(false);

  return (
    <div className="flex h-full w-full flex-col bg-sidebar text-sidebar-foreground">
      <div className="flex items-center justify-between px-4 py-3 border-b border-sidebar-border">
        <h2 className="font-semibold text-sm tracking-tight">Your AI Brain</h2>
        <button
          onClick={onClose}
          className="h-7 w-7 rounded-md flex items-center justify-center text-sidebar-foreground/50 hover:text-sidebar-foreground hover:bg-sidebar-accent transition-colors"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="flex border-b border-sidebar-border">
        <button
          onClick={() => setTab("memory")}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs font-medium transition-colors ${
            tab === "memory"
              ? "text-primary border-b-2 border-primary"
              : "text-sidebar-foreground/50 hover:text-sidebar-foreground"
          }`}
        >
          <Brain className="h-3.5 w-3.5" />
          Memory ({memories.length})
        </button>
        <button
          onClick={() => setTab("tasks")}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs font-medium transition-colors ${
            tab === "tasks"
              ? "text-primary border-b-2 border-primary"
              : "text-sidebar-foreground/50 hover:text-sidebar-foreground"
          }`}
        >
          <CheckSquare className="h-3.5 w-3.5" />
          Tasks ({pendingTasks.length})
        </button>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-3 space-y-2">
          {loading ? (
            <p className="text-xs text-sidebar-foreground/40 text-center py-8">Loading...</p>
          ) : tab === "memory" ? (
            memories.length === 0 ? (
              <div className="text-center py-8 space-y-2">
                <Brain className="h-8 w-8 mx-auto text-sidebar-foreground/20" />
                <p className="text-xs text-sidebar-foreground/40">
                  No memories yet. The AI learns about you as you chat.
                </p>
              </div>
            ) : (
              memories.map((mem) => (
                <div key={mem.id} className="group flex items-start gap-2 p-2 rounded-lg hover:bg-sidebar-accent/50 transition-colors">
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-sidebar-foreground/80 leading-relaxed">{mem.content}</p>
                    <span className={`inline-block mt-1 px-1.5 py-0.5 rounded text-[10px] font-medium ${categoryColors[mem.category] || categoryColors.fact}`}>
                      {mem.category}
                    </span>
                  </div>
                  <button
                    onClick={() => deleteMemory(mem.id)}
                    className="opacity-0 group-hover:opacity-100 h-6 w-6 shrink-0 flex items-center justify-center rounded text-sidebar-foreground/40 hover:text-destructive hover:bg-destructive/10 transition-all"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>
              ))
            )
          ) : (
            <>
              {pendingTasks.length === 0 && completedTasks.length === 0 ? (
                <div className="text-center py-8 space-y-2">
                  <CheckSquare className="h-8 w-8 mx-auto text-sidebar-foreground/20" />
                  <p className="text-xs text-sidebar-foreground/40">
                    No tasks yet. Ask the AI to remind you of something.
                  </p>
                </div>
              ) : (
                <>
                  {pendingTasks.map((task) => (
                    <div key={task.id} className="group flex items-start gap-2 p-2 rounded-lg hover:bg-sidebar-accent/50 transition-colors">
                      <button onClick={() => toggleTask(task.id, task.completed)} className="mt-0.5 shrink-0 text-sidebar-foreground/40 hover:text-primary transition-colors">
                        <Square className="h-4 w-4" />
                      </button>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-sidebar-foreground/80 leading-relaxed">{task.title}</p>
                        {task.dueDate && (
                          <p className="text-[10px] text-amber-400/70 mt-0.5">Due: {task.dueDate}</p>
                        )}
                      </div>
                      <button
                        onClick={() => deleteTask(task.id)}
                        className="opacity-0 group-hover:opacity-100 h-6 w-6 shrink-0 flex items-center justify-center rounded text-sidebar-foreground/40 hover:text-destructive hover:bg-destructive/10 transition-all"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  ))}

                  {completedTasks.length > 0 && (
                    <button
                      onClick={() => setShowCompleted(!showCompleted)}
                      className="flex items-center gap-1.5 text-[11px] text-sidebar-foreground/40 hover:text-sidebar-foreground/60 transition-colors py-1 px-2"
                    >
                      {showCompleted ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                      {completedTasks.length} completed
                    </button>
                  )}

                  {showCompleted && completedTasks.map((task) => (
                    <div key={task.id} className="group flex items-start gap-2 p-2 rounded-lg opacity-50">
                      <button onClick={() => toggleTask(task.id, task.completed)} className="mt-0.5 shrink-0 text-primary">
                        <CheckSquare className="h-4 w-4" />
                      </button>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-sidebar-foreground/60 line-through leading-relaxed">{task.title}</p>
                      </div>
                      <button
                        onClick={() => deleteTask(task.id)}
                        className="opacity-0 group-hover:opacity-100 h-6 w-6 shrink-0 flex items-center justify-center rounded text-sidebar-foreground/40 hover:text-destructive hover:bg-destructive/10 transition-all"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </>
              )}
            </>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
