import { useEffect, useLayoutEffect, useRef, useState, useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { SendHorizontal, Loader2, Paperclip, X, FileText, Camera, FlipHorizontal, Mic, Pencil, Trash2, Check } from "lucide-react";
import { VoiceMode } from "./voice-mode";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  useListOpenaiMessages,
  useGetOpenaiConversation,
  useUpdateOpenaiConversation,
  getListOpenaiMessagesQueryKey,
  getGetOpenaiConversationQueryKey,
  getListOpenaiConversationsQueryKey,
} from "@workspace/api-client-react";
import { Markdown } from "./markdown";

interface ChatAreaProps {
  conversationId: string;
  hideTitleBar?: boolean;
}

interface Attachment {
  id: string;
  name: string;
  file: File;
  isImage: boolean;
  content: string;
  previewUrl?: string;
}

interface Annotation {
  x: number;
  y: number;
  w: number;
  h: number;
  label: string;
}

function parseAnnotation(raw: string | null | undefined): Annotation | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    if (
      typeof parsed.x === "number" &&
      typeof parsed.y === "number" &&
      typeof parsed.w === "number" &&
      typeof parsed.h === "number"
    ) {
      return parsed as Annotation;
    }
  } catch {}
  return null;
}

function stripAnnotationMarker(text: string): string {
  return text.replace(/\s*ANNOTATION:\{[^}]*\}?\s*$/, "");
}

function CameraModal({ onCapture, onClose }: { onCapture: (file: File) => void; onClose: () => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<"environment" | "user">("environment");
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startCamera = useCallback(async (mode: "environment" | "user") => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    setReady(false);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: mode } });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch {
      setError("Camera access denied or unavailable.");
    }
  }, []);

  useEffect(() => {
    startCamera(facingMode);
    return () => { streamRef.current?.getTracks().forEach((t) => t.stop()); };
  }, [facingMode, startCamera]);

  const capture = () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video) return;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext("2d")?.drawImage(video, 0, 0);
    canvas.toBlob((blob) => {
      if (blob) {
        onCapture(new File([blob], `photo-${Date.now()}.jpg`, { type: "image/jpeg" }));
        onClose();
      }
    }, "image/jpeg", 0.92);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col">
      <div className="relative flex-1 overflow-hidden">
        {error ? (
          <div className="flex h-full items-center justify-center text-white text-sm px-6 text-center">{error}</div>
        ) : (
          <video ref={videoRef} autoPlay playsInline muted onCanPlay={() => setReady(true)} className="w-full h-full object-cover" />
        )}
        <canvas ref={canvasRef} className="hidden" />
        <div className="absolute top-0 inset-x-0 flex items-center justify-between px-4 py-4 bg-gradient-to-b from-black/60 to-transparent"
          style={{ paddingTop: "calc(env(safe-area-inset-top) + 1rem)" }}>
          <button onClick={onClose} className="text-white text-sm font-medium px-3 py-1.5 rounded-lg bg-white/10 backdrop-blur-sm">Cancel</button>
          <button onClick={() => setFacingMode((p) => p === "environment" ? "user" : "environment")} className="text-white p-2 rounded-full bg-white/10 backdrop-blur-sm">
            <FlipHorizontal className="h-5 w-5" />
          </button>
        </div>
      </div>
      <div className="flex items-center justify-center py-8 bg-black" style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 1.5rem)" }}>
        <button onClick={capture} disabled={!ready || !!error}
          className="h-20 w-20 rounded-full border-4 border-white bg-white/20 backdrop-blur-sm flex items-center justify-center disabled:opacity-40 active:scale-95 transition-transform">
          <div className="h-14 w-14 rounded-full bg-white" />
        </button>
      </div>
    </div>
  );
}

function AnnotatedImage({ src, alt, annotation }: { src: string; alt?: string; annotation: Annotation | null }) {
  return (
    <div className="relative rounded-xl overflow-hidden border bg-background mt-3">
      <img src={src} alt={alt || "Photo"} className="w-full h-auto block" />
      {annotation && (
        <div style={{
          position: "absolute",
          left: `${annotation.x}%`,
          top: `${annotation.y}%`,
          width: `${annotation.w}%`,
          height: `${annotation.h}%`,
          border: "2px solid #06b6d4",
          borderRadius: "6px",
          boxShadow: "0 0 0 1px rgba(0,0,0,0.4)",
          pointerEvents: "none",
        }}>
          <span style={{
            position: "absolute",
            bottom: "calc(100% + 4px)",
            left: 0,
            background: "#06b6d4",
            color: "#000",
            fontSize: "11px",
            fontWeight: 600,
            padding: "2px 6px",
            borderRadius: "4px",
            whiteSpace: "nowrap",
            maxWidth: "200px",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}>
            {annotation.label}
          </span>
        </div>
      )}
    </div>
  );
}

export function ChatArea({ conversationId, hideTitleBar }: ChatAreaProps) {
  const queryClient = useQueryClient();
  const idNum = parseInt(conversationId, 10);

  const { data: conversation, isLoading: isConvLoading } = useGetOpenaiConversation(idNum, {
    query: { enabled: !isNaN(idNum), queryKey: getGetOpenaiConversationQueryKey(idNum) },
  });

  const { data: messages, isLoading: isMessagesLoading } = useListOpenaiMessages(idNum, {
    query: { enabled: !isNaN(idNum), queryKey: getListOpenaiMessagesQueryKey(idNum) },
  });

  const updateConversation = useUpdateOpenaiConversation();

  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingText, setStreamingText] = useState("");
  const [streamingImage, setStreamingImage] = useState<{ b64_json: string; prompt: string } | null>(null);
  const [streamingAnnotation, setStreamingAnnotation] = useState<Annotation | null>(null);
  const [pendingImageSrc, setPendingImageSrc] = useState<string | null>(null);

  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [editTitle, setEditTitle] = useState("");
  const [showCamera, setShowCamera] = useState(false);
  const [showVoiceMode, setShowVoiceMode] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const titleInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const objectUrlsRef = useRef<Set<string>>(new Set());

  const scrollToBottom = useCallback(() => {
    requestAnimationFrame(() => {
      const el = scrollContainerRef.current;
      if (el) el.scrollTop = el.scrollHeight;
    });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, streamingText, streamingImage, scrollToBottom]);

  useLayoutEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 200) + "px";
  }, [input]);

  useEffect(() => {
    if (isEditingTitle && titleInputRef.current) titleInputRef.current.focus();
  }, [isEditingTitle]);

  useEffect(() => {
    return () => {
      objectUrlsRef.current.forEach((url) => URL.revokeObjectURL(url));
    };
  }, []);

  const processFiles = async (files: FileList | File[]) => {
    const newAttachments: Attachment[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isImage = file.type.startsWith("image/");
      try {
        const content = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = (e) => {
            let res = e.target?.result as string;
            if (isImage) res = res.split(",")[1];
            resolve(res);
          };
          reader.onerror = reject;
          if (isImage) reader.readAsDataURL(file);
          else reader.readAsText(file);
        });
        let previewUrl: string | undefined;
        if (isImage) {
          previewUrl = URL.createObjectURL(file);
          objectUrlsRef.current.add(previewUrl);
        }
        newAttachments.push({ id: Math.random().toString(36).substring(7), name: file.name, file, isImage, content, previewUrl });
      } catch (err) {
        console.error("Failed to read file", file.name, err);
      }
    }
    if (newAttachments.length > 0) setAttachments((prev) => [...prev, ...newAttachments]);
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => {
      const removed = prev.find((a) => a.id === id);
      if (removed?.previewUrl) {
        URL.revokeObjectURL(removed.previewUrl);
        objectUrlsRef.current.delete(removed.previewUrl);
      }
      return prev.filter((a) => a.id !== id);
    });
  };

  const handleDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsDragging(true); };
  const handleDragLeave = (e: React.DragEvent) => { e.preventDefault(); setIsDragging(false); };
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files?.length) processFiles(e.dataTransfer.files);
  };
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.length) processFiles(e.target.files);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSubmit = async (e?: React.FormEvent, overrideMessage?: string) => {
    if (e) e.preventDefault();
    const isResend = !!overrideMessage;
    const messageToSend = overrideMessage || input.trim();
    if ((!messageToSend && attachments.length === 0) || isStreaming) return;

    const userMessage = messageToSend;
    const currentAttachments = isResend ? [] : [...attachments];
    const firstImage = currentAttachments.find((a) => a.isImage);

    setInput("");
    if (!isResend) setAttachments([]);
    setIsStreaming(true);
    setStreamingText("");
    setStreamingImage(null);
    setStreamingAnnotation(null);
    setPendingImageSrc(firstImage?.previewUrl ?? null);
    setStatusMessage(null);

    const existingMsgCount = (messages || []).length;

    if (!isResend) {
      queryClient.setQueryData(getListOpenaiMessagesQueryKey(idNum), (old: any) => [
        ...(old || []),
        {
          id: -Date.now(),
          conversationId: idNum,
          role: "user",
          content: userMessage + (currentAttachments.length > 0 ? `\n[Attached ${currentAttachments.length} file(s)]` : ""),
          createdAt: new Date().toISOString(),
        },
      ]);
    }

    setTimeout(scrollToBottom, 50);

    let streamTextAccumulator = "";
    const abortController = new AbortController();
    const streamTimeout = setTimeout(() => abortController.abort(), 120000);

    try {
      const response = await fetch(`/api/openai/conversations/${idNum}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: abortController.signal,
        body: JSON.stringify({
          content: userMessage,
          attachments: currentAttachments.map((f) => ({
            name: f.name,
            type: f.isImage ? "image" : "text",
            content: f.content,
            mimeType: f.file.type,
          })),
        }),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const reader = response.body?.getReader();
      if (reader) {
        const decoder = new TextDecoder();
        let buffer = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";
          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith("data: ")) continue;
            try {
              const json = JSON.parse(trimmed.slice(6));
              if (json.done) break;
              if (json.status) setStatusMessage(json.status);
              if (json.content) {
                setStatusMessage(null);
                streamTextAccumulator += json.content;
                setStreamingText(stripAnnotationMarker(streamTextAccumulator));
              }
              if (json.image) setStreamingImage(json.image);
              if (json.annotation) setStreamingAnnotation(parseAnnotation(json.annotation));
              if (json.replaceContent !== undefined) {
                streamTextAccumulator = json.replaceContent;
                setStreamingText(stripAnnotationMarker(streamTextAccumulator));
              }
            } catch {}
          }
        }
      }
    } catch (error: any) {
      if (error?.name !== "AbortError") {
        console.error("Streaming error:", error);
      }
    } finally {
      clearTimeout(streamTimeout);
    }

    if (!streamTextAccumulator) {
      setStatusMessage("Finishing up…");
      for (let attempt = 0; attempt < 10; attempt++) {
        await new Promise((r) => setTimeout(r, 2000));
        try {
          const pollRes = await fetch(`/api/openai/conversations/${idNum}/messages`, { cache: "no-store" });
          if (!pollRes.ok) continue;
          const msgs = await pollRes.json();
          if (Array.isArray(msgs) && msgs.length > existingMsgCount + 1) {
            const lastMsg = msgs[msgs.length - 1];
            if (lastMsg && lastMsg.role === "assistant" && lastMsg.content) {
              streamTextAccumulator = lastMsg.content;
              setStreamingText(stripAnnotationMarker(streamTextAccumulator));
              break;
            }
          }
        } catch {}
      }
    }

    if (!streamTextAccumulator) {
      streamTextAccumulator = "Sorry, something went wrong. Please try again.";
    }

    setIsStreaming(false);
    setStatusMessage(null);
    setStreamingImage(null);
    setPendingImageSrc(null);
    setStreamingAnnotation(null);
    setStreamingText("");

    try {
      const freshMsgs = await fetch(`/api/openai/conversations/${idNum}/messages`, { cache: "no-store" });
      if (freshMsgs.ok) {
        const data = await freshMsgs.json();
        if (Array.isArray(data) && data.length > 0) {
          queryClient.setQueryData(getListOpenaiMessagesQueryKey(idNum), data);
        }
      }
    } catch {}

    queryClient.invalidateQueries({ queryKey: getGetOpenaiConversationQueryKey(idNum) });
    queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleEditMessage = async (messageId: number, newContent: string) => {
    try {
      await fetch(`/api/openai/conversations/${idNum}/messages/${messageId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: newContent }),
      });
      const freshMsgs = await fetch(`/api/openai/conversations/${idNum}/messages`, { cache: "no-store" });
      if (freshMsgs.ok) {
        const data = await freshMsgs.json();
        if (Array.isArray(data)) queryClient.setQueryData(getListOpenaiMessagesQueryKey(idNum), data);
      }
    } catch {}
  };

  const handleDeleteMessage = async (messageId: number) => {
    try {
      await fetch(`/api/openai/conversations/${idNum}/messages/${messageId}`, { method: "DELETE" });
      const freshMsgs = await fetch(`/api/openai/conversations/${idNum}/messages`, { cache: "no-store" });
      if (freshMsgs.ok) {
        const data = await freshMsgs.json();
        if (Array.isArray(data)) queryClient.setQueryData(getListOpenaiMessagesQueryKey(idNum), data);
      }
    } catch {}
  };

  const handleEditAndResend = async (messageId: number, newContent: string) => {
    try {
      const editRes = await fetch(`/api/openai/conversations/${idNum}/messages/${messageId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: newContent }),
      });
      if (!editRes.ok) return;
      const freshMsgs = await fetch(`/api/openai/conversations/${idNum}/messages`, { cache: "no-store" });
      if (freshMsgs.ok) {
        const data = await freshMsgs.json();
        if (Array.isArray(data)) queryClient.setQueryData(getListOpenaiMessagesQueryKey(idNum), data);
      }
    } catch { return; }
    setInput("");
    handleSubmit(undefined, newContent);
  };

  const handleSaveTitle = () => {
    if (editTitle.trim() && editTitle !== conversation?.title) {
      updateConversation.mutate(
        { id: idNum, data: { title: editTitle.trim() } },
        {
          onSuccess: (updatedConv) => {
            queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
            queryClient.setQueryData(getGetOpenaiConversationQueryKey(idNum), (old: any) =>
              old ? { ...old, title: updatedConv.title } : old
            );
          },
        }
      );
    }
    setIsEditingTitle(false);
  };

  if (isConvLoading || isMessagesLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!conversation) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-background">
        <div className="text-center text-muted-foreground">Conversation not found.</div>
      </div>
    );
  }

  return (
    <>
      {showVoiceMode && (
        <VoiceMode
          conversationId={idNum}
          onClose={() => setShowVoiceMode(false)}
          onMessagesUpdated={() => queryClient.invalidateQueries({ queryKey: getListOpenaiMessagesQueryKey(idNum) })}
        />
      )}

      {showCamera && (
        <CameraModal onCapture={(file) => processFiles([file])} onClose={() => setShowCamera(false)} />
      )}

      <div className="flex flex-1 min-h-0 w-full flex-col bg-background relative">
        {!hideTitleBar && (
          <div className="hidden md:flex h-12 items-center px-6 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-10 shrink-0">
            {isEditingTitle ? (
              <Input
                ref={titleInputRef}
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                onBlur={handleSaveTitle}
                onKeyDown={(e) => e.key === "Enter" && handleSaveTitle()}
                className="h-8 w-64 px-2 py-1 text-sm bg-muted/50 border-0 focus-visible:ring-1 focus-visible:ring-ring"
              />
            ) : (
              <h1
                className="text-[15px] font-medium tracking-tight cursor-pointer hover:text-primary transition-colors py-1 px-2 -ml-2 rounded-md hover:bg-muted/50 truncate max-w-[60vw]"
                onClick={() => { setEditTitle(conversation.title); setIsEditingTitle(true); }}
              >
                {conversation.title || "Chat"}
              </h1>
            )}
          </div>
        )}

        <div className="flex-1 min-h-0 overflow-y-auto px-4 md:px-8 lg:px-12" ref={scrollContainerRef}>
          <div className="max-w-3xl mx-auto flex flex-col gap-5 py-6 pb-4" style={{ minHeight: "100%" }}>
            <div style={{ flex: "1 1 0%" }} />
            {messages?.map((msg) => (
              <MessageBubble
                key={msg.id}
                messageId={msg.id}
                role={msg.role as "user" | "assistant"}
                content={msg.content}
                imageData={msg.imageData}
                annotationData={msg.annotationData}
                onEdit={msg.role === "user" && msg.id > 0 ? handleEditMessage : undefined}
                onDelete={msg.role === "user" && msg.id > 0 ? handleDeleteMessage : undefined}
                onEditAndResend={msg.role === "user" && msg.id > 0 ? handleEditAndResend : undefined}
              />
            ))}
            {isStreaming && (
              <MessageBubble
                role="assistant"
                content={streamingText}
                isStreaming
                statusMessage={statusMessage}
                streamImageData={streamingImage}
                streamAnnotation={streamingAnnotation}
                pendingImageSrc={pendingImageSrc}
              />
            )}
            <div ref={bottomRef} className="h-px" />
          </div>
        </div>

        <div className="p-3 pt-2 bg-background shrink-0 border-t border-border/30" style={{ paddingBottom: `calc(env(safe-area-inset-bottom) + 0.75rem)` }}>
          <div className="max-w-3xl mx-auto relative">
            {attachments.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-3">
                {attachments.map((att) => (
                  <div key={att.id} className="flex items-center gap-2 bg-secondary/80 rounded-full pl-2 pr-1 py-1 text-xs border border-border shadow-sm">
                    {att.isImage ? (
                      <div className="h-5 w-5 rounded-full overflow-hidden shrink-0">
                        <img src={att.previewUrl} alt="preview" className="h-full w-full object-cover" />
                      </div>
                    ) : (
                      <FileText className="h-3.5 w-3.5 text-muted-foreground" />
                    )}
                    <span className="max-w-[120px] truncate font-medium">{att.name}</span>
                    <button type="button" onClick={() => removeAttachment(att.id)}
                      className="h-5 w-5 rounded-full hover:bg-black/10 dark:hover:bg-white/10 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <form
              onSubmit={handleSubmit}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`relative flex flex-col bg-card rounded-2xl border shadow-sm transition-all duration-200 ${
                isDragging ? "ring-2 ring-primary border-primary bg-primary/5" : "focus-within:ring-1 focus-within:ring-ring focus-within:border-primary/50"
              }`}
            >
              {isDragging && (
                <div className="absolute inset-0 z-10 flex items-center justify-center bg-background/80 backdrop-blur-sm rounded-2xl border-2 border-dashed border-primary">
                  <div className="flex items-center gap-2 text-primary font-medium">
                    <Paperclip className="h-5 w-5" />Drop files to attach
                  </div>
                </div>
              )}

              <input type="file" multiple className="hidden" ref={fileInputRef} onChange={handleFileSelect}
                accept=".txt,.md,.js,.ts,.py,.json,.csv,.pdf,image/jpeg,image/png,image/gif,image/webp" />

              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask anything..."
                rows={1}
                disabled={isStreaming}
                className="w-full resize-none border-0 bg-transparent px-4 pt-3.5 pb-2 focus:outline-none placeholder:text-muted-foreground/50 text-foreground leading-relaxed min-h-[52px] max-h-[200px] overflow-y-auto"
                style={{ fontSize: "16px" }}
              />

              <div className="flex items-center justify-between px-2 pb-2">
                <div className="flex items-center gap-0.5">
                  <Button type="button" variant="ghost" size="icon"
                    className="h-8 w-8 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted/60"
                    onClick={() => fileInputRef.current?.click()}>
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <Button type="button" variant="ghost" size="icon"
                    className="h-8 w-8 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted/60"
                    onClick={() => setShowCamera(true)}>
                    <Camera className="h-4 w-4" />
                  </Button>
                  <Button type="button" variant="ghost" size="icon"
                    className="h-8 w-8 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted/60"
                    onClick={() => setShowVoiceMode(true)}>
                    <Mic className="h-4 w-4" />
                  </Button>
                </div>

                <Button type="submit"
                  size="icon"
                  disabled={(!input.trim() && attachments.length === 0) || isStreaming}
                  className="h-8 w-8 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-40">
                  {isStreaming ? <Loader2 className="h-4 w-4 animate-spin" /> : <SendHorizontal className="h-4 w-4" />}
                  <span className="sr-only">Send</span>
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}

function MessageBubble({
  role,
  content,
  messageId,
  imageData,
  annotationData,
  streamImageData,
  streamAnnotation,
  pendingImageSrc,
  isStreaming,
  statusMessage,
  onEdit,
  onDelete,
  onEditAndResend,
}: {
  role: "user" | "assistant";
  content: string;
  messageId?: number;
  imageData?: string | null;
  annotationData?: string | null;
  streamImageData?: { b64_json: string; prompt: string } | null;
  streamAnnotation?: Annotation | null;
  pendingImageSrc?: string | null;
  isStreaming?: boolean;
  statusMessage?: string | null;
  onEdit?: (id: number, content: string) => void;
  onDelete?: (id: number) => void;
  onEditAndResend?: (id: number, content: string) => void;
}) {
  const annotation = parseAnnotation(annotationData);
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(content);
  const editRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (isEditing && editRef.current) {
      editRef.current.focus();
      editRef.current.style.height = "auto";
      editRef.current.style.height = editRef.current.scrollHeight + "px";
    }
  }, [isEditing]);

  if (role === "user") {
    return (
      <div className="flex flex-col items-end w-full animate-fade-in group">
        <div className="max-w-[80%]">
          <div className="rounded-2xl px-5 py-3 text-[15px] bg-secondary text-secondary-foreground">
            {isEditing ? (
              <div className="flex flex-col gap-2">
                <textarea
                  ref={editRef}
                  value={editText}
                  onChange={(e) => {
                    setEditText(e.target.value);
                    e.target.style.height = "auto";
                    e.target.style.height = e.target.scrollHeight + "px";
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      if (editText.trim() && onEditAndResend && messageId) {
                        setIsEditing(false);
                        onEditAndResend(messageId, editText.trim());
                      }
                    }
                    if (e.key === "Escape") setIsEditing(false);
                  }}
                  className="bg-transparent border border-border/50 rounded-lg px-3 py-2 text-[15px] resize-none min-h-[40px] focus:outline-none focus:ring-1 focus:ring-primary/50 font-sans"
                  rows={1}
                />
                <div className="flex items-center gap-2 justify-end">
                  <button
                    onClick={() => setIsEditing(false)}
                    className="px-3 py-1 text-xs rounded-md hover:bg-secondary/80 text-muted-foreground"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      if (editText.trim() && onEdit && messageId) {
                        setIsEditing(false);
                        onEdit(messageId, editText.trim());
                      }
                    }}
                    className="px-3 py-1 text-xs rounded-md bg-primary/20 hover:bg-primary/30 text-primary"
                  >
                    Save
                  </button>
                  <button
                    onClick={() => {
                      if (editText.trim() && onEditAndResend && messageId) {
                        setIsEditing(false);
                        onEditAndResend(messageId, editText.trim());
                      }
                    }}
                    className="px-3 py-1 text-xs rounded-md bg-primary hover:bg-primary/90 text-primary-foreground"
                  >
                    Save & Resend
                  </button>
                </div>
              </div>
            ) : (
              <div className="whitespace-pre-wrap break-words font-sans">{content}</div>
            )}
          </div>
          {!isEditing && messageId && messageId > 0 && (onEdit || onDelete) && (
            <div className="flex items-center gap-1 mt-1 mr-1 opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity">
              {onEdit && (
                <button
                  onClick={(e) => { e.stopPropagation(); setEditText(content); setIsEditing(true); }}
                  className="p-1.5 rounded-md hover:bg-secondary/80 text-muted-foreground hover:text-foreground transition-colors"
                  title="Edit message"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
              )}
              {onDelete && (
                <button
                  onClick={(e) => { e.stopPropagation(); onDelete(messageId); }}
                  className="p-1.5 rounded-md hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-colors"
                  title="Delete message"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full animate-fade-in">
      <div className="flex items-start gap-3 text-[15px] min-w-0">
        <div className="h-7 w-7 mt-1 shrink-0 rounded-lg overflow-hidden border border-border/40">
          <img src="/icon.png" alt="Tro" className="h-full w-full object-cover" />
        </div>
        <div className="flex-1 flex flex-col gap-2 min-w-0">
        {statusMessage && isStreaming && !content && (
          <div className="flex items-center gap-2.5 text-sm text-muted-foreground animate-fade-in py-1">
            <div className="relative h-4 w-4 shrink-0">
              <span className="absolute inset-0 rounded-full bg-primary/20 animate-ping" />
              <span className="absolute inset-[3px] rounded-full bg-primary/70 animate-pulse" />
            </div>
            <span className="font-medium truncate max-w-[320px]">{statusMessage}</span>
          </div>
        )}

        {content ? (
          <div className="text-foreground">
            <Markdown content={content} />
            {isStreaming && !statusMessage && (
              <span className="inline-flex gap-1 ml-2">
                <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-blink" />
                <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-blink delay-100" />
                <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-blink delay-200" />
              </span>
            )}
          </div>
        ) : isStreaming && !statusMessage ? (
          <div className="h-6 flex items-center">
            <span className="inline-flex gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-blink" />
              <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-blink delay-100" />
              <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-blink delay-200" />
            </span>
          </div>
        ) : null}

        {isStreaming && pendingImageSrc && (
          <AnnotatedImage src={pendingImageSrc} annotation={streamAnnotation ?? null} />
        )}

        {imageData && (
          <div className="mt-3 rounded-xl overflow-hidden border bg-background">
            <img src={imageData} alt="Generated" className="w-full h-auto object-cover" />
          </div>
        )}

        {streamImageData && (
          <div className="mt-3 relative group rounded-xl overflow-hidden border bg-background">
            <img src={`data:image/png;base64,${streamImageData.b64_json}`} alt={streamImageData.prompt} className="w-full h-auto object-cover" />
            <div className="absolute bottom-0 inset-x-0 bg-black/60 backdrop-blur-sm p-2 text-[11px] text-white/90 transform translate-y-full group-hover:translate-y-0 transition-transform">
              {streamImageData.prompt}
            </div>
          </div>
        )}

        {annotationData && !imageData && (
          <div className="mt-1 text-xs text-muted-foreground italic">
            (Photo with annotation saved)
          </div>
        )}
        </div>
      </div>
    </div>
  );
}
