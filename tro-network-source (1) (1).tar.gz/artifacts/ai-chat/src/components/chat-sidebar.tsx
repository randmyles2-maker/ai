import { useState, useRef, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Plus, Trash2, Loader2, Search, Edit2, LogOut, Brain } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useClerk, useUser } from "@clerk/react";
import { format } from "date-fns";

import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { MemoryPanel } from "./memory-panel";
import {
  useListOpenaiConversations,
  useCreateOpenaiConversation,
  useDeleteOpenaiConversation,
  useUpdateOpenaiConversation,
  getListOpenaiConversationsQueryKey,
  getGetOpenaiConversationQueryKey,
} from "@workspace/api-client-react";

interface ChatSidebarProps {
  activeId?: string;
  onMobileClose?: () => void;
}

export function ChatSidebar({ activeId, onMobileClose }: ChatSidebarProps) {
  const [_, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { signOut } = useClerk();
  const { user } = useUser();
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editTitle, setEditTitle] = useState("");

  const [showMemory, setShowMemory] = useState(false);
  const { data: conversations, isLoading } = useListOpenaiConversations();
  const createConversation = useCreateOpenaiConversation();
  const deleteConversation = useDeleteOpenaiConversation();
  const updateConversation = useUpdateOpenaiConversation();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editingId && inputRef.current) {
      inputRef.current.focus();
    }
  }, [editingId]);

  const handleNewChat = () => {
    createConversation.mutate(
      { data: { title: "New Conversation" } },
      {
        onSuccess: (newConv) => {
          queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
          setLocation(`/chat/${newConv.id}`);
          if (onMobileClose) onMobileClose();
        },
      }
    );
  };

  const handleDelete = (e: React.MouseEvent, id: number) => {
    e.preventDefault();
    e.stopPropagation();
    deleteConversation.mutate(
      { id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
          if (activeId === id.toString()) {
            setLocation("/chat");
          }
        },
      }
    );
  };

  const handleStartEdit = (e: React.MouseEvent, id: number, currentTitle: string) => {
    e.preventDefault();
    e.stopPropagation();
    setEditingId(id);
    setEditTitle(currentTitle);
  };

  const handleSaveEdit = (e: React.FormEvent | React.FocusEvent) => {
    e.preventDefault();
    if (!editingId) return;
    if (editTitle.trim()) {
      updateConversation.mutate(
        { id: editingId, data: { title: editTitle.trim() } },
        {
          onSuccess: (updatedConv) => {
            queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
            queryClient.setQueryData(getGetOpenaiConversationQueryKey(editingId), (old: any) => {
              if (old) return { ...old, title: updatedConv.title };
              return old;
            });
          }
        }
      );
    }
    setEditingId(null);
  };

  const filteredConversations = conversations?.filter(c =>
    c.title.toLowerCase().includes(search.toLowerCase())
  );

  if (showMemory) {
    return <MemoryPanel onClose={() => setShowMemory(false)} />;
  }

  return (
    <div className="flex h-full w-full flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border">
      <div className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-md overflow-hidden shrink-0">
              <img src="/icon.png" alt="Tro" className="h-full w-full object-cover" />
            </div>
            <span className="font-semibold tracking-tight">Tro Network</span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-sidebar-foreground/50 hover:text-primary hover:bg-sidebar-accent"
            onClick={() => setShowMemory(true)}
            title="Memory & Tasks"
          >
            <Brain className="h-4 w-4" />
          </Button>
        </div>

        <Button
          onClick={handleNewChat}
          disabled={createConversation.isPending}
          className="w-full justify-start gap-2 bg-sidebar-accent hover:bg-sidebar-accent/80 text-sidebar-accent-foreground border-0 shadow-none h-10 font-medium"
          variant="outline"
        >
          {createConversation.isPending ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Plus className="h-4 w-4 text-sidebar-primary" />
          )}
          New Chat
        </Button>
      </div>

      <div className="px-4 pb-2">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-sidebar-foreground/40" />
          <Input
            placeholder="Search conversations..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-9 pl-9 bg-sidebar border-sidebar-border/50 focus-visible:ring-sidebar-ring text-sm"
          />
        </div>
      </div>

      <ScrollArea className="flex-1 overflow-y-auto px-2">
        <div className="space-y-0.5 p-2">
          {isLoading ? (
            <div className="py-8 flex justify-center">
              <Loader2 className="h-5 w-5 animate-spin text-sidebar-foreground/30" />
            </div>
          ) : filteredConversations?.length === 0 ? (
            <div className="py-8 text-center text-sm text-sidebar-foreground/50">
              {search ? "No matches found" : "No conversations yet"}
            </div>
          ) : (
            filteredConversations?.map((conv) => {
              const isActive = activeId === conv.id.toString();
              const isEditing = editingId === conv.id;

              if (isEditing) {
                return (
                  <div key={conv.id} className="flex items-center gap-2 rounded-md px-3 py-2 bg-sidebar-accent border border-sidebar-border">
                    <form onSubmit={handleSaveEdit} className="flex-1 flex items-center gap-2">
                      <Input
                        ref={inputRef}
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        onBlur={handleSaveEdit}
                        className="h-7 px-2 py-1 text-sm bg-background border-sidebar-border/50"
                      />
                    </form>
                  </div>
                );
              }

              return (
                <Link
                  key={conv.id}
                  href={`/chat/${conv.id}`}
                  className={`group flex flex-col gap-1 rounded-md px-3 py-2 text-sm transition-all duration-200 ${
                    isActive
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50"
                  }`}
                  onClick={() => onMobileClose?.()}
                >
                  <span className={`truncate block ${isActive ? "font-medium" : ""}`}>
                    {conv.title}
                  </span>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-sidebar-foreground/40 font-medium">
                      {format(new Date(conv.updatedAt), "MMM d, h:mm a")}
                    </span>
                    <div className={`flex items-center gap-1 transition-opacity ${isActive ? "opacity-100" : "md:opacity-0 md:group-hover:opacity-100 opacity-100"}`}>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-5 w-5 hover:bg-sidebar-foreground/10 text-sidebar-foreground/60 hover:text-sidebar-foreground"
                        onClick={(e) => handleStartEdit(e, conv.id, conv.title)}
                      >
                        <Edit2 className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-5 w-5 hover:bg-destructive/10 text-sidebar-foreground/60 hover:text-destructive"
                        onClick={(e) => handleDelete(e, conv.id)}
                        disabled={deleteConversation.isPending}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </Link>
              );
            })
          )}
        </div>
      </ScrollArea>

      {/* User profile + sign-out */}
      <div className="p-3 border-t border-sidebar-border shrink-0">
        <div className="flex items-center gap-3 rounded-lg px-2 py-2">
          <div className="h-8 w-8 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0 text-primary font-semibold text-sm">
            {user?.firstName?.[0] ?? user?.emailAddresses?.[0]?.emailAddress?.[0]?.toUpperCase() ?? "?"}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate text-sidebar-foreground">
              {user?.firstName ?? user?.emailAddresses?.[0]?.emailAddress ?? "User"}
            </p>
            <p className="text-[10px] text-sidebar-foreground/40 truncate">
              {user?.emailAddresses?.[0]?.emailAddress}
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 shrink-0 text-sidebar-foreground/50 hover:text-sidebar-foreground hover:bg-sidebar-foreground/10"
            onClick={() => signOut(() => setLocation("/"))}
            title="Sign out"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
