import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db } from "@workspace/db";
import { conversations, messages, userMemories, userTasks } from "@workspace/db";
import { eq, desc, and, asc } from "drizzle-orm";
import { openai } from "@workspace/integrations-openai-ai-server";
import { generateImageBuffer } from "@workspace/integrations-openai-ai-server/image";
import {
  speechToText,
  textToSpeech,
  ensureCompatibleFormat,
} from "@workspace/integrations-openai-ai-server/audio";
import {
  CreateOpenaiConversationBody,
  GetOpenaiConversationParams,
  UpdateOpenaiConversationParams,
  UpdateOpenaiConversationBody,
  DeleteOpenaiConversationParams,
  ListOpenaiMessagesParams,
  SendOpenaiMessageParams,
  SendOpenaiMessageBody,
  UpdateOpenaiMessageParams,
  UpdateOpenaiMessageBody,
} from "@workspace/api-zod";
import { gte } from "drizzle-orm";
import type OpenAI from "openai";

const router = Router();

// ─── Auth middleware ──────────────────────────────────────────────────────────

function requireAuth(req: any, res: any, next: any) {
  const auth = getAuth(req);
  const userId = auth?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  req.userId = userId;
  next();
}

router.use(requireAuth);

// ─── Conversation CRUD ────────────────────────────────────────────────────────

router.get("/conversations", async (req: any, res): Promise<void> => {
  const rows = await db
    .select()
    .from(conversations)
    .where(eq(conversations.userId, req.userId))
    .orderBy(desc(conversations.updatedAt));
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  res.setHeader("Pragma", "no-cache");
  res.json(rows);
});

router.post("/conversations", async (req: any, res): Promise<void> => {
  const parsed = CreateOpenaiConversationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [conv] = await db
    .insert(conversations)
    .values({ title: parsed.data.title, userId: req.userId })
    .returning();
  res.status(201).json(conv);
});

router.get("/conversations/:id", async (req: any, res): Promise<void> => {
  const parsed = GetOpenaiConversationParams.safeParse({ id: Number(req.params["id"]) });
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { id } = parsed.data;
  const [conv] = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, req.userId)));
  if (!conv) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  const msgs = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(messages.createdAt);
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  res.setHeader("Pragma", "no-cache");
  res.json({ ...conv, messages: msgs });
});

router.patch("/conversations/:id", async (req: any, res): Promise<void> => {
  const paramsParsed = UpdateOpenaiConversationParams.safeParse({ id: Number(req.params["id"]) });
  if (!paramsParsed.success) {
    res.status(400).json({ error: paramsParsed.error.message });
    return;
  }
  const bodyParsed = UpdateOpenaiConversationBody.safeParse(req.body);
  if (!bodyParsed.success) {
    res.status(400).json({ error: bodyParsed.error.message });
    return;
  }
  const { id } = paramsParsed.data;
  const [existing] = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, req.userId)));
  if (!existing) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  const [updated] = await db
    .update(conversations)
    .set({ title: bodyParsed.data.title, updatedAt: new Date() })
    .where(and(eq(conversations.id, id), eq(conversations.userId, req.userId)))
    .returning();
  res.json(updated);
});

router.delete("/conversations/:id", async (req: any, res): Promise<void> => {
  const parsed = DeleteOpenaiConversationParams.safeParse({ id: Number(req.params["id"]) });
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { id } = parsed.data;
  const [existing] = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, req.userId)));
  if (!existing) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  await db.delete(messages).where(eq(messages.conversationId, id));
  await db.delete(conversations).where(and(eq(conversations.id, id), eq(conversations.userId, req.userId)));
  res.status(204).end();
});

// ─── Messages list ────────────────────────────────────────────────────────────

router.get("/conversations/:id/messages", async (req: any, res): Promise<void> => {
  const parsed = ListOpenaiMessagesParams.safeParse({ id: Number(req.params["id"]) });
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { id } = parsed.data;
  const [conv] = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, req.userId)));
  if (!conv) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  const msgs = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(messages.createdAt);
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  res.setHeader("Pragma", "no-cache");
  res.json(msgs);
});

// ─── Edit message ────────────────────────────────────────────────────────────

router.put("/conversations/:conversationId/messages/:messageId", async (req: any, res): Promise<void> => {
  const params = UpdateOpenaiMessageParams.safeParse({
    conversationId: Number(req.params["conversationId"]),
    messageId: Number(req.params["messageId"]),
  });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const body = UpdateOpenaiMessageBody.safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: body.error.message }); return; }

  const { conversationId, messageId } = params.data;
  const [conv] = await db.select().from(conversations)
    .where(and(eq(conversations.id, conversationId), eq(conversations.userId, req.userId)));
  if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }

  const [msg] = await db.select().from(messages)
    .where(and(eq(messages.id, messageId), eq(messages.conversationId, conversationId)));
  if (!msg) { res.status(404).json({ error: "Message not found" }); return; }
  if (msg.role !== "user") { res.status(400).json({ error: "Can only edit user messages" }); return; }

  const [updated] = await db.update(messages)
    .set({ content: body.data.content })
    .where(eq(messages.id, messageId))
    .returning();

  await db.delete(messages).where(
    and(
      eq(messages.conversationId, conversationId),
      gte(messages.id, messageId + 1)
    )
  );

  res.json(updated);
});

// ─── Delete message ──────────────────────────────────────────────────────────

router.delete("/conversations/:conversationId/messages/:messageId", async (req: any, res): Promise<void> => {
  const conversationId = Number(req.params["conversationId"]);
  const messageId = Number(req.params["messageId"]);
  if (!conversationId || !messageId) { res.status(400).json({ error: "Invalid params" }); return; }

  const [conv] = await db.select().from(conversations)
    .where(and(eq(conversations.id, conversationId), eq(conversations.userId, req.userId)));
  if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }

  const [msg] = await db.select().from(messages)
    .where(and(eq(messages.id, messageId), eq(messages.conversationId, conversationId)));
  if (!msg) { res.status(404).json({ error: "Message not found" }); return; }
  if (msg.role !== "user") { res.status(400).json({ error: "Can only delete user messages" }); return; }

  const toDelete = await db.select({ id: messages.id }).from(messages)
    .where(and(eq(messages.conversationId, conversationId), gte(messages.id, messageId)));

  await db.delete(messages).where(
    and(
      eq(messages.conversationId, conversationId),
      gte(messages.id, messageId)
    )
  );

  res.json({ deleted: toDelete.length });
});

// ─── Helpers ──────────────────────────────────────────────────────────────────

function extractAnnotation(text: string): { clean: string; annotation: string | null } {
  const match = text.match(/\bANNOTATION:(\{[^}]+\})/);
  if (!match) return { clean: text, annotation: null };
  const clean = text.replace(/\s*ANNOTATION:\{[^}]+\}/, "").trim();
  return { clean, annotation: match[1] };
}

async function executeWebSearch(query: string): Promise<string> {
  try {
    const response = await (openai as any).responses.create({
      model: "gpt-5-mini",
      input: query,
      tools: [{ type: "web_search_preview" }],
    });
    if (response.output_text) return response.output_text;
    if (Array.isArray(response.output)) {
      for (const item of response.output) {
        if (item.type === "message" && Array.isArray(item.content)) {
          const texts = item.content
            .filter((c: any) => c.type === "output_text" || c.type === "text")
            .map((c: any) => c.text)
            .join("");
          if (texts) return texts;
        }
      }
    }
    return "No results found for that search.";
  } catch (err) {
    console.error("Web search error:", err);
    return "Web search failed. I'll answer from my training data instead.";
  }
}

// Fetch and extract text from a URL
async function executeFetchUrl(url: string): Promise<string> {
  try {
    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; TroNetwork/1.0)" },
      signal: AbortSignal.timeout(10000),
    });
    if (!res.ok) return `Failed to fetch URL (HTTP ${res.status}).`;
    const html = await res.text();
    // Strip HTML tags, scripts, styles
    const text = html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/g, " ")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/\s{3,}/g, "\n\n")
      .trim()
      .slice(0, 12000);
    return text || "Could not extract readable content from this URL.";
  } catch (err: any) {
    return `Could not fetch that URL: ${err?.message ?? "Unknown error"}`;
  }
}

// Generate smart conversation title from first message
async function generateTitle(userMessage: string): Promise<string> {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-5-nano",
      max_completion_tokens: 20,
      messages: [
        {
          role: "system",
          content: "Generate a short, specific title (3-6 words, no quotes, no punctuation at end) that captures what this conversation is about. Be specific, not generic.",
        },
        { role: "user", content: userMessage.slice(0, 500) },
      ],
    });
    return completion.choices[0]?.message?.content?.trim() || userMessage.slice(0, 60);
  } catch {
    return userMessage.slice(0, 60);
  }
}

// ─── Memory System ───────────────────────────────────────────────────────────

async function loadUserMemories(userId: string): Promise<string> {
  const memories = await db
    .select()
    .from(userMemories)
    .where(eq(userMemories.userId, userId))
    .orderBy(desc(userMemories.updatedAt));
  if (memories.length === 0) return "";
  const grouped: Record<string, string[]> = {};
  for (const m of memories) {
    const cat = m.category || "fact";
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(m.content);
  }

  const coreCategories = ["fact", "preference", "goal", "relationship", "context", "routine", "interest", "personality"];
  const metaCategories = ["pattern", "insight"];

  let block = "\n\n## User Profile (persistent memory)\n";
  for (const [cat, items] of Object.entries(grouped)) {
    if (coreCategories.includes(cat)) {
      block += `**${cat}**: ${items.join("; ")}\n`;
    }
  }
  const patterns = Object.entries(grouped).filter(([cat]) => metaCategories.includes(cat));
  if (patterns.length > 0) {
    block += "\n**Observed patterns & insights**:\n";
    for (const [, items] of patterns) {
      for (const item of items) {
        block += `- ${item}\n`;
      }
    }
  }
  block += "\nYou know this user deeply. Use this knowledge actively — reference their name, situation, goals, and preferences naturally. Tailor every response to who they are. Connect dots across conversations. You're not a generic assistant; you're THEIR assistant.";
  return block;
}

async function loadUserTasks(userId: string): Promise<string> {
  const tasks = await db
    .select()
    .from(userTasks)
    .where(and(eq(userTasks.userId, userId), eq(userTasks.completed, false)))
    .orderBy(asc(userTasks.createdAt));
  if (tasks.length === 0) return "";
  let block = "\n\n## User's pending tasks/reminders\n";
  for (const t of tasks) {
    block += `- ${t.title}${t.dueDate ? ` (due: ${t.dueDate})` : ""}${t.description ? ` — ${t.description}` : ""}\n`;
  }
  block += "\nProactively mention relevant pending tasks when the context fits. If a user asks what they have going on, list these.";
  return block;
}

async function extractAndSaveMemories(userId: string, userMsg: string, aiResponse: string): Promise<void> {
  try {
    const existingMemories = await db
      .select()
      .from(userMemories)
      .where(eq(userMemories.userId, userId));
    const existingSummary = existingMemories.map((m) => `[${m.category}] ${m.content}`).join("\n");

    const completion = await openai.chat.completions.create({
      model: "gpt-5-nano",
      max_completion_tokens: 600,

      messages: [
        {
          role: "system",
          content: `You are a memory system that builds an evolving profile of the user. You extract new facts AND detect patterns from conversations.

Output a JSON array: [{"content":"fact or pattern","category":"...","action":"add|update","updateTarget":"exact text of memory to update (only if action=update)"}]

Categories: preference, fact, context, goal, relationship, interest, routine, personality, pattern, insight

## What to extract:
- Identity: name, age, location, nationality, languages
- Work: job, company, skills, projects, colleagues
- Preferences: likes, dislikes, opinions, values
- Goals: plans, aspirations, deadlines
- Relationships: family, friends, pets, partner
- Interests: hobbies, topics, things they follow
- Routines: habits, schedules, recurring activities
- Personality: communication style, humor, energy
- Context: current situations, challenges, events
- **Patterns**: recurring behaviors, tendencies, habits you notice (e.g., "Tends to ask about X frequently", "Usually works late", "Prefers detailed explanations")
- **Insights**: things you can infer about the user (e.g., "Seems to be preparing for a career change based on recent questions")

## Smart updates:
- If a new fact UPDATES or CONTRADICTS an existing memory, use action "update" and specify the old memory text in "updateTarget"
- Example: if existing memory says "Works at Google" and user now says "I just started at Apple", output: {"content":"Works at Apple","category":"fact","action":"update","updateTarget":"Works at Google"}
- For genuinely new facts, use action "add"

## Existing memories:
${existingSummary || "(none yet)"}

If nothing worth remembering, output []. Never extract generic knowledge.`,
        },
        {
          role: "user",
          content: `User said: "${userMsg.slice(0, 1000)}"\nAI responded: "${aiResponse.slice(0, 500)}"`,
        },
      ],
    });
    const raw = completion.choices[0]?.message?.content?.trim() || "[]";
    const match = raw.match(/\[[\s\S]*\]/);
    if (!match) return;
    const facts = JSON.parse(match[0]) as { content: string; category: string; action?: string; updateTarget?: string }[];
    for (const fact of facts) {
      if (!fact.content || fact.content.length <= 3) continue;

      if (fact.action === "update" && fact.updateTarget) {
        const toUpdate = existingMemories.find((m) => m.content === fact.updateTarget);
        if (toUpdate) {
          await db
            .update(userMemories)
            .set({ content: fact.content, category: fact.category || toUpdate.category, updatedAt: new Date() })
            .where(eq(userMemories.id, toUpdate.id));
          continue;
        }
      }

      const isDuplicate = existingMemories.some(
        (m) => m.content === fact.content || m.content.toLowerCase() === fact.content.toLowerCase()
      );
      if (!isDuplicate) {
        await db.insert(userMemories).values({
          userId,
          content: fact.content,
          category: fact.category || "fact",
        });
      }
    }
  } catch (err) {
    console.error("Memory extraction error (non-fatal):", err);
  }
}

// ─── Pre-response Intelligence (Proactive Search Decision) ───────────────────

function shouldForceSearch(content: string): { shouldSearch: boolean; query: string } {
  const lower = content.toLowerCase();
  const len = content.length;

  if (len < 10) return { shouldSearch: false, query: "" };

  const searchTriggers = [
    "weather", "stock", "price", "news", "latest", "current", "today",
    "yesterday", "this week", "this month", "score", "result", "who won",
    "how much does", "how much is", "what happened", "release date",
    "when does", "when did", "when will", "is it true", "fact check",
    "net worth", "population", "exchange rate", "convert", "crypto",
    "bitcoin", "ethereum", "dow", "nasdaq", "s&p", "inflation",
    "election", "president", "ceo of", "founder of",
  ];

  const noSearchSignals = [
    "write", "code", "function", "create", "build", "make me",
    "explain how", "what is a", "define", "help me", "advice",
    "remember", "remind", "hi", "hello", "hey", "thanks",
    "from your knowledge", "don't search",
  ];

  if (noSearchSignals.some((s) => lower.includes(s))) return { shouldSearch: false, query: "" };
  if (searchTriggers.some((t) => lower.includes(t))) return { shouldSearch: true, query: content.slice(0, 200) };

  return { shouldSearch: false, query: "" };
}

// ─── Multi-Step Verification (Draft → Critique → Web-Verify → Refine) ────────

async function verifySelfCorrect(
  userMessage: string,
  aiResponse: string,
): Promise<{ corrected: boolean; output: string }> {
  try {
    if (aiResponse.length < 20) return { corrected: false, output: aiResponse };

    // STEP 1: Critique — find all issues + identify claims needing verification
    const critiqueCompletion = await openai.chat.completions.create({
      model: "gpt-5-nano",
      max_completion_tokens: 2048,

      messages: [
        {
          role: "system",
          content: `You are a ruthless critic, fact-checker, and hallucination detector. Your ONLY job is to find errors in the AI response below. Be thorough and harsh.

## Check for:
- **Hallucinated facts**: Made-up names, events, dates, statistics, quotes, or studies that don't exist
- **Fabricated sources**: URLs, paper titles, book names, or citations that were invented
- **Wrong numbers**: Incorrect calculations, percentages, arithmetic, unit conversions, statistics
- **Factual errors**: Wrong dates, names, places, events, science, definitions
- **Reasoning errors**: Flawed logic, invalid conclusions, non-sequiturs, circular reasoning
- **Logical contradictions**: Statements that contradict each other within the response
- **Misleading statements**: Technically true but missing critical context
- **Outdated information**: Facts that may have changed
- **Confidence without basis**: Stating uncertain things with false confidence

## Hallucination red flags:
- Suspiciously specific statistics without obvious source (e.g., "Studies show 73.2% of...")
- Named studies, researchers, or papers that sound plausible but might not exist
- Very precise dates for historical events that are commonly misremembered
- Product features or pricing that could be outdated

## Rules:
- If the response is fully correct, output exactly: NO_ISSUES
- If you find problems, list each one clearly:
  ISSUE: [description — quote the exact wrong text]
  SEVERITY: [critical/moderate/minor]
  FIX: [what should be corrected]
  VERIFY: [optional search query to verify this claim, if uncertain]
- Do NOT flag subjective opinions, creative content, or stylistic choices.
- Only flag things you are confident are objectively wrong or highly suspicious.`,
        },
        {
          role: "user",
          content: `User asked: "${userMessage.slice(0, 800)}"\n\nAI responded:\n${aiResponse}`,
        },
      ],
    });

    const critique = critiqueCompletion.choices[0]?.message?.content?.trim() || "";

    if (!critique || critique === "NO_ISSUES") {
      return { corrected: false, output: aiResponse };
    }

    // STEP 1.5: Web-verify critical claims if VERIFY queries exist
    const verifyMatches = critique.matchAll(/VERIFY:\s*(.+)/g);
    let webVerification = "";
    let verifyCount = 0;
    for (const match of verifyMatches) {
      if (verifyCount >= 3) break;
      try {
        const searchResult = await executeWebSearch(match[1].trim());
        webVerification += `\nWeb verification for "${match[1].trim()}":\n${searchResult.slice(0, 800)}\n`;
        verifyCount++;
      } catch {}
    }

    // STEP 2: Refine — apply the fixes with web verification context
    const refineCompletion = await openai.chat.completions.create({
      model: "gpt-5-nano",
      max_completion_tokens: 4096,

      messages: [
        {
          role: "system",
          content: `You are a precision editor. You will receive an AI response, a critique listing errors, and optional web verification results. Your job is to rewrite the response with ALL confirmed errors fixed.

Rules:
- Output the COMPLETE corrected response — the entire rewritten text, not just the fixes.
- Preserve the original tone, style, length, and markdown formatting exactly.
- CRITICAL: Preserve the SAME language as the original. If Spanish, stay Spanish. If Japanese, stay Japanese.
- Only change the specific things confirmed as wrong. Keep everything else identical.
- If web verification confirms the original was right, keep the original text.
- If web verification shows the critique was wrong, keep the original text for that issue.
- Remove any hallucinated citations/sources that can't be verified.
- Do NOT add disclaimers, notes, or commentary about what you changed.
- The output should read as if the AI had gotten it right the first time.`,
        },
        {
          role: "user",
          content: `ORIGINAL RESPONSE:\n${aiResponse}\n\nCRITIQUE (errors found):\n${critique}${webVerification ? `\n\nWEB VERIFICATION RESULTS:\n${webVerification}` : ""}`,
        },
      ],
    });

    const refined = refineCompletion.choices[0]?.message?.content?.trim() || "";

    if (!refined || refined.length < 10) {
      return { corrected: false, output: aiResponse };
    }

    return { corrected: true, output: refined };
  } catch (err) {
    console.error("Self-correction error (non-fatal):", err);
    return { corrected: false, output: aiResponse };
  }
}

// ─── Smart Model Router ──────────────────────────────────────────────────────

function selectModel(content: string, hasImages: boolean): { model: string; maxTokens: number } {
  const lower = content.toLowerCase();
  const len = content.length;

  if (hasImages) {
    return { model: "gpt-5.2", maxTokens: 8192 };
  }

  const isTrivial =
    len < 60 &&
    !lower.includes("why") &&
    !lower.includes("how") &&
    !lower.includes("explain") &&
    !lower.includes("compare") &&
    !lower.includes("analyze") &&
    !lower.includes("think") &&
    !lower.includes("reason") &&
    !lower.includes("debate") &&
    !lower.includes("prove") &&
    !lower.includes("solve") &&
    !lower.includes("advice") &&
    !lower.includes("recommend") &&
    !lower.includes("strategy") &&
    !lower.includes("plan") &&
    !lower.includes("help me") &&
    !lower.includes("write") &&
    !lower.includes("create") &&
    !lower.includes("build") &&
    (lower.match(/^(hi|hello|hey|thanks|thank you|ok|okay|yes|no|sure|got it|cool|nice|good|bye|goodbye|gm|gn|sup|yo)/i) ||
      (lower.match(/^(what is|what's|who is|who's|when is|when's|where is|where's|define |translate |convert )/i) &&
        !lower.includes("and") && !lower.includes("versus") && !lower.includes(" vs ")));

  if (isTrivial) {
    return { model: "gpt-5-nano", maxTokens: 1024 };
  }

  const isDeep =
    len > 300 ||
    lower.includes("analyze") ||
    lower.includes("compare") ||
    lower.includes("prove") ||
    lower.includes("derive") ||
    lower.includes("solve") ||
    lower.includes("debate") ||
    lower.includes("evaluate") ||
    lower.includes("critique") ||
    lower.includes("essay") ||
    lower.includes("research") ||
    lower.includes("step by step") ||
    lower.includes("in depth") ||
    lower.includes("think about") ||
    lower.includes("pros and cons") ||
    lower.includes("trade-off");

  if (isDeep) {
    return { model: "gpt-5-mini", maxTokens: 8192 };
  }

  return { model: "gpt-5-mini", maxTokens: 4096 };
}

// ─── Tools definition ─────────────────────────────────────────────────────────

const TOOLS: OpenAI.ChatCompletionTool[] = [
  {
    type: "function",
    function: {
      name: "web_search",
      description:
        "Search the internet for current information, news, prices, events, people, companies, or anything that may have changed recently or that you're not certain about. Use this liberally — when in doubt, search.",
      parameters: {
        type: "object",
        properties: {
          query: {
            type: "string",
            description: "A specific, well-formed search query",
          },
        },
        required: ["query"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "fetch_url",
      description:
        "Read and extract the full text content of any URL. Use when the user shares a link and wants you to read, summarize, or analyze it.",
      parameters: {
        type: "object",
        properties: {
          url: {
            type: "string",
            description: "The full HTTPS URL to fetch",
          },
        },
        required: ["url"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "generate_image",
      description:
        "Generate an image based on a description. Use when the user asks you to create, draw, make, generate, or illustrate an image or picture.",
      parameters: {
        type: "object",
        properties: {
          prompt: {
            type: "string",
            description: "A detailed description of the image to generate",
          },
        },
        required: ["prompt"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "save_memory",
      description:
        "Save an important fact about the user to persistent memory. Use when the user tells you their name, job, preferences, projects, goals, or any personal info worth remembering long-term. Also use when the user says 'remember this' or 'don't forget'.",
      parameters: {
        type: "object",
        properties: {
          content: {
            type: "string",
            description: "The fact to remember (e.g., 'User's name is Alex', 'Prefers Python over JavaScript')",
          },
          category: {
            type: "string",
            enum: ["preference", "fact", "context", "goal"],
            description: "Category of the memory",
          },
        },
        required: ["content", "category"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "create_task",
      description:
        "Create a task or reminder for the user. Use when the user asks you to remind them of something, set a reminder, create a to-do, or track an action item.",
      parameters: {
        type: "object",
        properties: {
          title: {
            type: "string",
            description: "Short title for the task/reminder",
          },
          description: {
            type: "string",
            description: "Optional detailed description",
          },
          due_date: {
            type: "string",
            description: "Optional due date (e.g., 'tomorrow', '2026-04-15', 'next Monday')",
          },
        },
        required: ["title"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "complete_task",
      description:
        "Mark a task/reminder as completed. Use when the user says they've done something or asks to check off a task.",
      parameters: {
        type: "object",
        properties: {
          task_title: {
            type: "string",
            description: "The title (or close match) of the task to complete",
          },
        },
        required: ["task_title"],
      },
    },
  },
];

// ─── Send message ─────────────────────────────────────────────────────────────

router.post("/conversations/:id/messages", async (req: any, res): Promise<void> => {
  const paramsParsed = SendOpenaiMessageParams.safeParse({ id: Number(req.params["id"]) });
  if (!paramsParsed.success) {
    res.status(400).json({ error: paramsParsed.error.message });
    return;
  }
  const bodyParsed = SendOpenaiMessageBody.safeParse(req.body);
  if (!bodyParsed.success) {
    res.status(400).json({ error: bodyParsed.error.message });
    return;
  }

  const { id } = paramsParsed.data;
  const { content, attachments } = bodyParsed.data;

  const [conv] = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, req.userId)));
  if (!conv) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  const hasImages = attachments?.some((a) => a.type === "image") ?? false;

  // Build user message content (with attachments)
  let userContent: string | OpenAI.ChatCompletionContentPart[];
  if (attachments && attachments.length > 0) {
    const parts: OpenAI.ChatCompletionContentPart[] = [{ type: "text", text: content }];
    for (const att of attachments) {
      if (att.type === "image") {
        parts.push({
          type: "image_url",
          image_url: { url: `data:${att.mimeType ?? "image/png"};base64,${att.content}` },
        });
      } else {
        parts.push({
          type: "text",
          text: `[Attached file: ${att.name}]\n\`\`\`\n${att.content}\n\`\`\``,
        });
      }
    }
    userContent = parts;
  } else {
    userContent = content;
  }

  // ─── Stream Setup (flush IMMEDIATELY so users see something fast) ──
  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-store");
  res.setHeader("Connection", "close");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  let clientDisconnected = false;
  req.on("close", () => { clientDisconnected = true; });

  const flush = () => { try { if ((res as any).flush) (res as any).flush(); } catch {} };
  const sendSSE = (data: Record<string, unknown>) => {
    if (!res.writableEnded && !clientDisconnected) {
      try { res.write(`data: ${JSON.stringify(data)}\n\n`); flush(); } catch {}
    }
  };
  const sendStatus = (msg: string) => sendSSE({ status: msg });

  // Smart model routing based on message complexity
  const { model: selectedModel, maxTokens } = selectModel(content, hasImages);
  const isTrivialMsg = selectedModel === "gpt-5-nano";

  // ─── Run ALL pre-work in parallel: DB history + memory + tasks + search decision ──
  const searchDecision = isTrivialMsg ? { shouldSearch: false, query: "" } : shouldForceSearch(content);

  const [history, memoryBlock, tasksBlock] = await Promise.all([
    db.select().from(messages).where(eq(messages.conversationId, id)).orderBy(messages.createdAt),
    isTrivialMsg ? Promise.resolve("") : loadUserMemories(req.userId),
    isTrivialMsg ? Promise.resolve("") : loadUserTasks(req.userId),
  ]);

  // Insert user message (fire-and-forget — don't block stream)
  db.insert(messages).values({ conversationId: id, role: "user", content }).catch(console.error);

  // Title generation — fire and forget
  const isFirstMessage = history.length === 0;
  if (isFirstMessage || conv.title === "New Conversation") {
    generateTitle(content).then((title) => {
      db.update(conversations).set({ title, updatedAt: new Date() }).where(eq(conversations.id, id)).catch(console.error);
    });
  } else {
    db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, id)).catch(() => {});
  }

  // Pre-search in parallel with system prompt build (don't block)
  let preSearchResults = "";
  if (searchDecision.shouldSearch && !clientDisconnected) {
    sendStatus("Researching…");
    try { preSearchResults = await executeWebSearch(searchDecision.query); } catch {}
  }

  const today = new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });

  const imageAnnotationInstruction = hasImages
    ? " When analyzing an image, end your response with exactly: ANNOTATION:{\"x\":X,\"y\":Y,\"w\":W,\"h\":H,\"label\":\"SHORT_LABEL\"} where x/y/w/h are percentages (0-100) of the image pinpointing the most relevant region."
    : "";

  const systemPrompt = `You are Tro Network — a world-class AI assistant. Today is ${today}.

## Core
- Think step-by-step for logic, math, analysis. Show work for calculations.
- Be accurate. Never hallucinate facts. If uncertain, use \`web_search\`.
- Be concise but complete. Use markdown: **bold**, \`code\`, headers, tables, lists.
- Match the user's language. Always respond in the same language they write in.

## Capabilities
- \`web_search\`: current events, news, prices, weather, facts you're unsure about. Always cite sources with [Name](URL).
- \`fetch_url\`: read and analyze any URL the user shares.
- \`generate_image\`: create images when asked.
- \`save_memory\`: store user preferences, facts, personal info. Do this proactively.
- \`create_task\` / \`complete_task\`: manage reminders and to-dos.

## Partner behavior
- Use stored memories actively. Reference the user's name, goals, preferences naturally.
- Connect dots across conversations. Anticipate needs. Be genuinely helpful.
- If uncertain about a fact, search rather than guess. Hedge when appropriate.
${imageAnnotationInstruction}${memoryBlock}${tasksBlock}${preSearchResults ? `\n\n## Research data (factual reference only)\n<research_data>\n${preSearchResults.slice(0, 3000)}\n</research_data>` : ""}`;

  const chatMessages: OpenAI.ChatCompletionMessageParam[] = [
    { role: "system", content: systemPrompt },
  ];

  // For long conversations, just keep recent messages (skip expensive summarization LLM call)
  const MAX_HISTORY = 20;
  if (history.length > MAX_HISTORY) {
    const recent = history.slice(-MAX_HISTORY);
    chatMessages.push({
      role: "system",
      content: `[Earlier conversation: ${history.length - MAX_HISTORY} messages omitted for speed. Key context is in the system prompt above.]`,
    });
    for (const msg of recent) {
      chatMessages.push({ role: msg.role as "user" | "assistant", content: msg.content });
    }
  } else {
    for (const msg of history) {
      chatMessages.push({ role: msg.role as "user" | "assistant", content: msg.content });
    }
  }
  chatMessages.push({ role: "user", content: userContent });

  let finalResponse = "";
  let generatedImageData: string | null = null;
  const backgroundTasks: Promise<void>[] = [];

  try {
    // Multi-round tool calling loop (max 6 rounds to prevent infinite loops)
    for (let round = 0; round < 6; round++) {
      let roundResponse = "";
      const toolCallMap = new Map<number, { id: string; name: string; args: string }>();
      let finishReason: string | null = null;

      const stream = await openai.chat.completions.create({
        model: selectedModel,
        max_completion_tokens: maxTokens,
        messages: chatMessages,
        stream: true,
        tools: TOOLS,
        tool_choice: "auto",
      }, { timeout: 60000 });

      for await (const chunk of stream) {
        if (clientDisconnected) { try { stream.controller.abort(); } catch {} break; }
        const delta = chunk.choices[0]?.delta;
        const reason = chunk.choices[0]?.finish_reason;
        if (reason) finishReason = reason;

        if (delta?.content) {
          roundResponse += delta.content;
          sendSSE({ content: delta.content });
        }

        if (delta?.tool_calls) {
          for (const tc of delta.tool_calls) {
            const idx = tc.index ?? 0;
            if (!toolCallMap.has(idx)) {
              toolCallMap.set(idx, { id: "", name: "", args: "" });
            }
            const cur = toolCallMap.get(idx)!;
            if (tc.id) cur.id = tc.id;
            if (tc.function?.name) cur.name = tc.function.name;
            if (tc.function?.arguments) cur.args += tc.function.arguments;
          }
        }
      }

      finalResponse += roundResponse;

      // No tool calls — we have our final answer
      if (finishReason !== "tool_calls" || toolCallMap.size === 0) break;

      const toolCalls = Array.from(toolCallMap.values());

      // Add assistant message with the tool_calls
      chatMessages.push({
        role: "assistant",
        content: roundResponse || null,
        tool_calls: toolCalls.map((tc) => ({
          id: tc.id,
          type: "function" as const,
          function: { name: tc.name, arguments: tc.args },
        })),
      } as OpenAI.ChatCompletionMessageParam);

      // Execute tools — search/fetch sequentially (need results), image gen in background
      const searchFetchTools = toolCalls.filter((tc) => tc.name === "web_search" || tc.name === "fetch_url");
      const imageTools = toolCalls.filter((tc) => tc.name === "generate_image");
      const actionTools = toolCalls.filter((tc) => tc.name === "save_memory" || tc.name === "create_task" || tc.name === "complete_task");

      // Execute action tools instantly (DB writes are fast)
      for (const tc of actionTools) {
        let toolResult = "";
        try {
          const args = JSON.parse(tc.args || "{}");
          if (tc.name === "save_memory") {
            const existing = await db
              .select()
              .from(userMemories)
              .where(and(eq(userMemories.userId, req.userId), eq(userMemories.content, args.content)));
            if (existing.length === 0) {
              await db.insert(userMemories).values({
                userId: req.userId,
                content: args.content,
                category: args.category || "fact",
              });
              toolResult = `Saved to memory: "${args.content}"`;
              sendSSE({ status: "Remembered ✓" });
            } else {
              toolResult = `Already remembered: "${args.content}"`;
            }
          } else if (tc.name === "create_task") {
            await db.insert(userTasks).values({
              userId: req.userId,
              title: args.title,
              description: args.description || null,
              dueDate: args.due_date || null,
            });
            toolResult = `Task created: "${args.title}"${args.due_date ? ` (due: ${args.due_date})` : ""}`;
            sendSSE({ status: "Task created ✓" });
          } else if (tc.name === "complete_task") {
            const tasks = await db
              .select()
              .from(userTasks)
              .where(and(eq(userTasks.userId, req.userId), eq(userTasks.completed, false)));
            const match = tasks.find((t) =>
              t.title.toLowerCase().includes(args.task_title.toLowerCase()) ||
              args.task_title.toLowerCase().includes(t.title.toLowerCase())
            );
            if (match) {
              await db
                .update(userTasks)
                .set({ completed: true, updatedAt: new Date() })
                .where(eq(userTasks.id, match.id));
              toolResult = `Task completed: "${match.title}"`;
              sendSSE({ status: "Task completed ✓" });
            } else {
              toolResult = `No matching pending task found for: "${args.task_title}"`;
            }
          }
        } catch (err) {
          toolResult = `Action error: ${String(err)}`;
        }
        chatMessages.push({
          role: "tool",
          tool_call_id: tc.id,
          content: toolResult,
        } as OpenAI.ChatCompletionMessageParam);
      }

      // Fire image generation in parallel immediately — don't block text streaming
      for (const tc of imageTools) {
        try {
          const args = JSON.parse(tc.args || "{}");
          sendSSE({ status: "Generating image…" });

          // Kick off image gen without awaiting — text streams while image is generated
          const task = generateImageBuffer(args.prompt, "1024x1024")
            .then((imageBuffer) => {
              const b64 = imageBuffer.toString("base64");
              generatedImageData = `data:image/png;base64,${b64}`;
              if (!res.writableEnded) {
                sendSSE({ image: { b64_json: b64, prompt: args.prompt } });
              }
            })
            .catch((err) => console.error("Image gen error:", err));
          backgroundTasks.push(task);

          // Tell AI image is being generated so it responds immediately
          chatMessages.push({
            role: "tool",
            tool_call_id: tc.id,
            content: `Image generation started in background for: "${args.prompt}". Tell the user what you're creating and that the image will appear shortly.`,
          } as OpenAI.ChatCompletionMessageParam);
        } catch (err) {
          chatMessages.push({
            role: "tool",
            tool_call_id: tc.id,
            content: `Image generation error: ${String(err)}`,
          } as OpenAI.ChatCompletionMessageParam);
        }
      }

      // Execute search/fetch tools (results needed before AI can answer)
      for (const tc of searchFetchTools) {
        let toolResult = "";
        try {
          const args = JSON.parse(tc.args || "{}");
          if (tc.name === "web_search") {
            sendSSE({ status: `Searching: ${args.query}` });
            toolResult = await executeWebSearch(args.query);
          } else if (tc.name === "fetch_url") {
            sendSSE({ status: `Reading: ${args.url}` });
            toolResult = await executeFetchUrl(args.url);
          }
        } catch (err) {
          toolResult = `Tool error: ${String(err)}`;
        }
        chatMessages.push({
          role: "tool",
          tool_call_id: tc.id,
          content: toolResult,
        } as OpenAI.ChatCompletionMessageParam);
      }

      // If only image tools were called (no search/fetch), break so AI streams its response
      // The next round will synthesize after background image fires
      if (searchFetchTools.length === 0 && imageTools.length > 0) {
        // Let the next loop iteration stream the AI's text response immediately
      }
      // Continue to next round to get AI's synthesis of tool results
    }

    if (backgroundTasks.length > 0 && !clientDisconnected) {
      await Promise.race([
        Promise.all(backgroundTasks),
        new Promise((resolve) => setTimeout(resolve, 30000)),
      ]);
    }
  } catch (err) {
    console.error("AI stream error:", err);
    if (!res.writableEnded && !clientDisconnected) {
      const errMsg = "\n\nSorry, I encountered an error. Please try again.";
      finalResponse += errMsg;
      sendSSE({ content: errMsg });
    }
  }

  const { clean: cleanResponse, annotation } = extractAnnotation(finalResponse);
  let storedContent = annotation ? cleanResponse : finalResponse;

  if (annotation && hasImages && !res.writableEnded) {
    sendSSE({ annotation, replaceContent: cleanResponse });
  }

  let insertedMsgId: number | null = null;
  if (storedContent) {
    try {
      const [inserted] = await db.insert(messages).values({
        conversationId: id,
        role: "assistant",
        content: storedContent,
        imageData: generatedImageData,
        annotationData: annotation,
      }).returning();
      if (inserted) insertedMsgId = inserted.id;
    } catch (dbErr) {
      console.error("Failed to save assistant message:", dbErr);
    }
  }

  if (!res.writableEnded) {
    try {
      sendSSE({ done: true });
      res.end();
    } catch {}
  }

  if (!clientDisconnected && storedContent && insertedMsgId && !isTrivialMsg && storedContent.length >= 40) {
    const msgId = insertedMsgId;
    verifySelfCorrect(content, storedContent)
      .then(async ({ corrected, output }) => {
        if (corrected) {
          await db.update(messages).set({ content: output }).where(eq(messages.id, msgId));
        }
      })
      .catch(() => {});
  }

  if (!clientDisconnected && !isTrivialMsg) {
    extractAndSaveMemories(req.userId, content, storedContent).catch(() => {});
  }
});

// ─── Voice endpoint ───────────────────────────────────────────────────────────

router.post("/conversations/:id/voice", async (req: any, res): Promise<void> => {
  const id = parseInt(req.params["id"], 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  try {
    const [conv] = await db
      .select()
      .from(conversations)
      .where(and(eq(conversations.id, id), eq(conversations.userId, req.userId)));
    if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }

    const { audioBase64 } = req.body as { audioBase64: string; mimeType: string };
    if (!audioBase64) { res.status(400).json({ error: "audioBase64 required" }); return; }

    const rawBuf = Buffer.from(audioBase64, "base64");
    const { buffer: compatBuf, format } = await ensureCompatibleFormat(rawBuf);
    const transcript = await speechToText(compatBuf, format);

    if (!transcript.trim()) {
      res.json({ transcript: "", aiText: "", audioBase64: "" });
      return;
    }

    await db.insert(messages).values({ conversationId: id, role: "user", content: transcript });
    await db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, id));

    const history = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, id))
      .orderBy(messages.createdAt);

    const today = new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });

    const voiceHistory = history.length > 10 ? history.slice(-10) : history;
    const completion = await openai.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 256,
      messages: [
        {
          role: "system",
          content: `You are Tro Network, a powerful AI assistant. Today is ${today}. You are in voice mode — respond conversationally in 1-3 short sentences. No bullet points, no markdown, no lists. Be natural, direct, and accurate.`,
        },
        ...voiceHistory.map((m) => ({ role: m.role as "user" | "assistant", content: m.content })),
      ],
    });

    const aiText = completion.choices[0]?.message?.content ?? "";

    if (aiText) {
      await db.insert(messages).values({ conversationId: id, role: "assistant", content: aiText });
    }

    let responseAudioBase64 = "";
    try {
      const audioBuffer = await textToSpeech(aiText, "nova", "mp3");
      responseAudioBase64 = audioBuffer.toString("base64");
    } catch (ttsErr) {
      console.error("TTS error (non-fatal):", ttsErr);
    }

    res.json({ transcript, aiText, audioBase64: responseAudioBase64 });
  } catch (err) {
    console.error("Voice route error:", err);
    if (!res.headersSent) {
      res.status(500).json({ error: "Voice processing failed. Please try again." });
    }
  }
});

// ─── Memories CRUD ───────────────────────────────────────────────────────────

router.get("/memories", async (req: any, res): Promise<void> => {
  try {
    const memories = await db
      .select()
      .from(userMemories)
      .where(eq(userMemories.userId, req.userId))
      .orderBy(desc(userMemories.updatedAt));
    res.json(memories);
  } catch (err) {
    console.error("Memories fetch error:", err);
    res.status(500).json({ error: "Failed to load memories" });
  }
});

router.delete("/memories/:id", async (req: any, res): Promise<void> => {
  const memId = parseInt(req.params["id"], 10);
  if (isNaN(memId)) { res.status(400).json({ error: "Invalid id" }); return; }
  try {
    await db
      .delete(userMemories)
      .where(and(eq(userMemories.id, memId), eq(userMemories.userId, req.userId)));
    res.status(204).end();
  } catch (err) {
    console.error("Memory delete error:", err);
    res.status(500).json({ error: "Failed to delete memory" });
  }
});

// ─── Tasks CRUD ──────────────────────────────────────────────────────────────

router.get("/tasks", async (req: any, res): Promise<void> => {
  try {
    const tasks = await db
      .select()
      .from(userTasks)
      .where(eq(userTasks.userId, req.userId))
      .orderBy(desc(userTasks.createdAt));
    res.json(tasks);
  } catch (err) {
    console.error("Tasks fetch error:", err);
    res.status(500).json({ error: "Failed to load tasks" });
  }
});

router.patch("/tasks/:id", async (req: any, res): Promise<void> => {
  const taskId = parseInt(req.params["id"], 10);
  if (isNaN(taskId)) { res.status(400).json({ error: "Invalid id" }); return; }
  try {
    const { completed, title } = req.body as { completed?: boolean; title?: string };
    const updates: Record<string, any> = { updatedAt: new Date() };
    if (completed !== undefined) updates.completed = completed;
    if (title !== undefined) updates.title = title;
    const [updated] = await db
      .update(userTasks)
      .set(updates)
      .where(and(eq(userTasks.id, taskId), eq(userTasks.userId, req.userId)))
      .returning();
    if (!updated) { res.status(404).json({ error: "Task not found" }); return; }
    res.json(updated);
  } catch (err) {
    console.error("Task update error:", err);
    res.status(500).json({ error: "Failed to update task" });
  }
});

router.delete("/tasks/:id", async (req: any, res): Promise<void> => {
  const taskId = parseInt(req.params["id"], 10);
  if (isNaN(taskId)) { res.status(400).json({ error: "Invalid id" }); return; }
  try {
    await db
      .delete(userTasks)
      .where(and(eq(userTasks.id, taskId), eq(userTasks.userId, req.userId)));
    res.status(204).end();
  } catch (err) {
    console.error("Task delete error:", err);
    res.status(500).json({ error: "Failed to delete task" });
  }
});

export default router;
